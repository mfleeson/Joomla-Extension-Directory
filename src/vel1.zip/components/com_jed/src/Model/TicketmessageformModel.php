<?php

/**
 * @package JED
 *
 * @subpackage TICKETS
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jed\Component\Jed\Site\Model;

// No direct access.
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;

// phpcs:enable PSR1.Files.SideEffects

use Exception;
use Jed\Component\Jed\Site\Helper\JedHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\FormModel;
use Joomla\CMS\Table\Table;
use Joomla\Registry\Registry;
use Joomla\Utilities\ArrayHelper;

/**
 * Jed model.
 *
 * @since 4.0.0
 */
class TicketmessageformModel extends FormModel
{
    /**
     * The item object
     *
     * @var   object
     * @since 4.0.0
     */
    private mixed $item;
    /**
     * Data Table
     *
     * @since 4.0.0
     **/
    private string $dbtable = "#__jed_ticket_messages";

    /**
     * Method to get the profile form.
     *
     * The base form is loaded from XML
     *
     * @param array $data     An optional array of data for the form to interogate.
     * @param bool  $loadData True if the form is to load its own data (default case), false if not.
     *
     * @return Form    A Form object on success, false on failure
     *
     * @since  4.0.0
     * @throws Exception
     */
    public function getForm($data = [], $loadData = true, $formname = 'jform'): Form
    {
        // Get the form.
        $form = $this->loadForm(
            'com_jed.ticketmessage',
            'ticketmessageform',
            [
                        'control'   => $formname,
                        'load_data' => $loadData,
                ]
        );

        if (! is_object($form)) {
            throw new Exception(Text::_('JERROR_LOADFILE_FAILED'), 500);
        }

        return $form;
    }

    /**
     * Method to get the table
     *
     * @param string $name
     * @param string $prefix  Optional prefix for the table class name
     * @param array  $options
     *
     * @return Table|bool Table if found, bool false on failure
     *
     * @since  4.0.0
     * @throws Exception
     */
    public function getTable($name = 'Ticketmessage', $prefix = 'Administrator', $options = []): Table|bool
    {
        return parent::getTable($name, $prefix, $options);
    }

    /**
     * Removes the "internal" field for users who don't have core.manage on com_jed - only
     * managers may flag a ticket message as internal-only.
     *
     * @param Form   $form  The form to process.
     * @param mixed  $data  The data to bind to the form.
     * @param string $group The name of the plugin group to import.
     *
     * @return void
     *
     * @since 4.0.0
     * @throws Exception
     */
    protected function preprocessForm(Form $form, $data, $group = 'content'): void
    {
        parent::preprocessForm($form, $data, $group);

        if (!Factory::getApplication()->getIdentity()->authorise('core.manage', 'com_jed')) {
            $form->removeField('internal');
        }
    }

    /**
     * Method to delete data
     *
     * @param int  $pk  Item primary key
     *
     * @return int  The id of the deleted item
     *
     * @since  4.0.0
     * @throws Exception
     */
    /*  public function delete($pk) : bool
        {
            $user = Factory::getApplication()->getIdentity();

            if (!$pk || JedHelper::userIDItem($pk, $this->dbtable) || JedHelper::isAdminOrSuperUser())
            {
                if (empty($pk))
                {
                    $pk = (int) $this->getState('ticketmessage.id');
                }

                if ($pk == 0 || $this->getItem($pk) == null)
                {
                    throw new Exception(Text::_('COM_JED_ITEM_DOESNT_EXIST'), 404);
                }

                if ($user->authorise('core.delete', 'com_jed') !== true)
                {
                    throw new Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
                }

                $table = $this->getTable();

                if ($table->delete($pk) !== true)
                {
                    throw new Exception(Text::_('JERROR_FAILED'), 501);
                }

                return $pk;
            }
            else
            {
                throw new Exception(Text::_("JERROR_ALERTNOAUTHOR"), 401);
            }
        } */

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed  The default data is an empty array.
     * @since  4.0.0
     * @throws Exception
     */
    protected function loadFormData(): mixed
    {
        $data = Factory::getApplication()->getUserState('com_jed.edit.ticketmessage.data', []);

        if (empty($data)) {
            $data = $this->getItem();
        }

        if ($data) {
            return $data;
        }

        return [];
    }

    /**
     * Method to autopopulate the model state.
     *
     * Note. Calling getState in this method will result in recursion.
     *
     * @return void
     *
     * @since 4.0.0
     *
     * @throws Exception
     */
    protected function populateState(): void
    {
        /* @var $app \Joomla\CMS\Application\SiteApplication */
        $app = Factory::getApplication();

        // Load state from the request userState on edit or from the passed variable on default
        if (Factory::getApplication()->input->get('layout') == 'edit') {
            $id = Factory::getApplication()->getUserState('com_jed.edit.ticketmessage.id');
        } else {
            $id = Factory::getApplication()->input->get('id');
            Factory::getApplication()->setUserState('com_jed.edit.ticketmessage.id', $id);
        }

        $this->setState('ticketmessage.id', $id);

        // Load the parameters.
        $params       = $app->getParams();
        $params_array = $params->toArray();

        if (isset($params_array['item_id'])) {
            $this->setState('ticketmessage.id', $params_array['item_id']);
        }

        $this->setState('params', $params);
    }

    /**
     * Method to get an ojbect.
     *
     * @param int|null $id The id of the object to get.
     *
     * @return Object|bool Object on success, false on failure.
     *
     * @since  4.0.0
     * @throws Exception
     */
    public function getItem(int $id = null): mixed
    {
        if ($this->item === null) {
            $this->item = false;

            if (empty($id)) {
                $id = $this->getState('ticketmessage.id');
            }

            // Get a level row instance.
            $table = $this->getTable();

            if ($table !== false && $table->load($id) && ! empty($table->id)) {
                $user = Factory::getApplication()->getIdentity();

                if (
                    JedHelper::isAdminOrSuperUser() || $table->created_by == Factory::getApplication()->getIdentity(
                    )->id
                ) {
                    $canEdit = $user->authorise('core.edit', 'com_jed') || $user->authorise('core.create', 'com_jed');

                    if (! $canEdit && $user->authorise('core.edit.own', 'com_jed')) {
                        $canEdit = $user->id == $table->created_by;
                    }

                    if (! $canEdit) {
                        throw new Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
                    }

                    // Convert the Table to a clean stdClass.
                    // Convert the Table to a clean stdClass.
                    $properties = get_object_vars($table);
                    $item       = ArrayHelper::toObject($properties);

                    if (property_exists($item, 'params')) {
                        $registry     = new Registry($item->params);
                        $item->params = $registry->toArray();
                    }

                    if (isset($this->item->category_id) && is_object($this->item->category_id)) {
                        $this->item->category_id = ArrayHelper::fromObject($this->item->category_id);
                    }
                } else {
                    throw new Exception(Text::_("JERROR_ALERTNOAUTHOR"), 401);
                }
            }
        }

        return $this->item;
    }

    /**
     * Method to save the form data.
     *
     * @param array $data The form data
     *
     * @return bool
     *
     * @since  4.0.0
     * @throws Exception
     */
    public function save(array $data): bool
    {
        $id = (! empty($data['id'])) ? $data['id'] : (int)$this->getState('ticketmessage.id');

        $isLoggedIn = JedHelper::isLoggedIn();

        if (! $id || JedHelper::userIDItem($id, $this->dbtable) || JedHelper::isAdminOrSuperUser() && $isLoggedIn) {
            $table = $this->getTable();

            if ($table->save($data) === true) {
                return $table->id;
            }
            return false;
        }
        throw new Exception(Text::_("JERROR_ALERTNOAUTHOR"), 401);
    }
}
