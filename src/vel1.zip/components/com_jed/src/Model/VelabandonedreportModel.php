<?php

/**
 * @package JED
 *
 * @subpackage VEL
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jed\Component\Jed\Site\Model;

// No direct access.
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;

// phpcs:enable PSR1.Files.SideEffects

use Exception;
use Jed\Component\Jed\Site\Helper\JedHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\ItemModel;
use Joomla\CMS\Table\Table;
use Joomla\Registry\Registry;
use Joomla\Utilities\ArrayHelper;

/**
 * VEL Abandoned Report Model Class.
 *
 * @since 4.0
 */
class VelabandonedreportModel extends ItemModel
{
    /**
     * The item object
     *
     * @var   object
     * @since 4.0.0
     */
    private mixed $item = null;

    /**
     * Data Table
     *
     * @since 4.0.0
     **/
    private string $dbtable = "#__jed_vel_abandoned_report";

    /**
     * Method to check in an item.
     *
     * @param int|null $id The id of the row to check out.
     *
     * @return bool True on success, false on failure.
     *
     * @since 4.0.0
     *
     * @throws Exception
     */
    public function checkin(int $id = null): bool
    {
        // Get the id.
        $id = (!empty($id)) ? $id : (int)$this->getState('velabandonedreport.id');
        if ($id || JedHelper::userIDItem($id, $this->dbtable) || JedHelper::isAdminOrSuperUser()) {
            if ($id) {
                // Initialise the table
                $table = $this->getTable();

                // Attempt to check the row in.
                if (method_exists($table, 'checkin')) {
                    if (!$table->checkin($id)) {
                        return false;
                    }
                }
            }

            return true;
        } else {
            throw new Exception(Text::_("JERROR_ALERTNOAUTHOR"), 401);
        }
    }

    /**
     * Method to check out an item for editing.
     *
     * @param int|null $id The id of the row to check out.
     *
     * @return bool True on success, false on failure.
     *
     * @since 4.0.0
     *
     * @throws Exception
     */
    public function checkout(int $id = null): bool
    {
        // Get the user id.
        $id = (!empty($id)) ? $id : (int)$this->getState('velabandonedreport.id');

        if ($id || JedHelper::userIDItem($id, $this->dbtable) || JedHelper::isAdminOrSuperUser()) {
            if ($id) {
                // Initialise the table
                $table = $this->getTable();

                // Get the current user object.
                $user = Factory::getApplication()->getIdentity();

                // Attempt to check the row out.
                if (method_exists($table, 'checkout')) {
                    if (!$table->checkout($user->id, $id)) {
                        return false;
                    }
                }
            }

            return true;
        } else {
            throw new Exception(Text::_("JERROR_ALERTNOAUTHOR"), 401);
        }
    }

    /**
     * Method to get a single record.
     *
     * @param int|null $pk The id of the object to get.
     *
     * @return object    Object on success, false on failure.
     *
     * @since  4.0.0
     * @throws Exception
     */
    public function getItem($pk = null): mixed
    {
        /* @var $app \Joomla\CMS\Application\SiteApplication */
        $app = Factory::getApplication();
        if ($this->item === null) {
            $this->item = false;

            if (empty($pk)) {
                $pk = $this->getState('velabandonedreport.id');
            }

            // Get a level row instance.
            $table = $this->getTable();

            // Attempt to load the row.
            if ($table->load($pk)) {
                if (empty($result) || JedHelper::isAdminOrSuperUser()) {
                    // Check published state.
                    if ($published = $this->getState('filter.published')) {
                        if (isset($table->state) && $table->state != $published) {
                            throw new Exception(Text::_('COM_JED_ITEM_NOT_LOADED'), 403);
                        }
                    }

                    // Convert the Table to a clean stdClass.
                    $properties = get_object_vars($table);
                    $item       = ArrayHelper::toObject($properties);

                    if (property_exists($item, 'params')) {
                        $registry     = new Registry($item->params);
                        $item->params = $registry->toArray();
                    }
                } else {
                    $app->enqueueMessage("Sorry you did not create that report item", "message");

                    return null;
                    //throw new Exception(Text::_("JERROR_ALERTNOAUTHOR"), 401);
                }
            }

            if (empty($this->item)) {
                $app->enqueueMessage(Text::_('COM_JED_SECURITY_CANT_LOAD'), "message");

                return null;
            }
        }


        if (!empty($this->item->consent_to_process) || $this->item->consent_to_process == 0) {
            $this->item->consent_to_process = Text::_(
                'COM_JED_GENERAL_CONSENT_TO_PROCESS_OPTION_' . $this->item->consent_to_process
            );
        }

        if (!empty($this->item->passed_to_vel) || $this->item->passed_to_vel == 0) {
            $this->item->passed_to_vel = Text::_(
                'COM_JED_VEL_GENERAL_PASSED_TO_VEL_OPTION_' . $this->item->passed_to_vel
            );
        }

        if (!empty($this->item->data_source) || $this->item->data_source == 0) {
            $this->item->data_source = Text::_(
                'COM_JED_VEL_GENERAL_DATA_SOURCE_OPTION_' . $this->item->data_source
            );
        }

        if (isset($this->item->created_by)) {
            $this->item->created_by_name = JedHelper::getUserById($this->item->created_by)->name;
        }

        if (isset($this->item->modified_by)) {
            $this->item->modified_by_name = JedHelper::getUserById($this->item->modified_by)->name;
        }

        return $this->item;
    }

    /**
     * Get an instance of Table class
     *
     * @param string $name
     * @param string $prefix  Prefix for the table class name. Optional.
     * @param array  $options
     *
     * @return Table Table if success
     * @since  4.0.0
     * @throws Exception
     */
    public function getTable($name = 'Velabandonedreport', $prefix = 'Administrator', $options = []): Table
    {
        return parent::getTable($name, $prefix, $options);
    }

    /**
     * Method to autopopulate the model state.
     *
     * Note. Calling getState in this method will result in recursion.
     *
     * @return void
     *
     * @since 4.0.0
     *
     * @throws Exception
     */
    protected function populateState(): void
    {
        $app  = Factory::getApplication();
        $user = Factory::getApplication()->getIdentity();

        // Check published state
        if ((!$user->authorise('core.edit.state', 'com_jed')) && (!$user->authorise('core.edit', 'com_jed'))) {
            $this->setState('filter.published', 1);
            $this->setState('filter.archived', 2);
        }

        // Load state from the request userState on edit or from the passed variable on default
        if (Factory::getApplication()->input->get('layout') == 'edit') {
            $id = Factory::getApplication()->getUserState('com_jed.edit.velabandonedreport.id');
        } else {
            $id = Factory::getApplication()->input->get('id');
            Factory::getApplication()->setUserState('com_jed.edit.velabandonedreport.id', $id);
        }

        $this->setState('velabandonedreport.id', $id);

        // Load the parameters.
        $params       = $app->getParams();
        $params_array = $params->toArray();

        if (isset($params_array['item_id'])) {
            $this->setState('velabandonedreport.id', $params_array['item_id']);
        }

        $this->setState('params', $params);
    }
}
