<?php

/**
 * @package JED
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jed\Component\Jed\Site\Model;

// No direct access.
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Exception;
use Jed\Component\Jed\Site\Helper\JedHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use Joomla\Database\QueryInterface;

/**
 * Methods supporting a list of Jed records.
 *
 * @since 4.0.0
 */
class ReviewsModel extends ListModel
{
    /**
     * Constructor.
     *
     * @param array $config An optional associative array of configuration settings.
     *
     * @see    JController
     * @since  4.0.0
     * @throws Exception
     */
    public function __construct($config = [])
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'a.id',
                'extension_id', 'a.extension_id',
                'title', 'a.title',
                'alias', 'a.alias',
                'body', 'a.body',
                'functionality', 'a.functionality',
                'functionality_comment', 'a.functionality_comment',
                'ease_of_use', 'a.ease_of_use',
                'ease_of_use_comment', 'a.ease_of_use_comment',
                'support', 'a.support',
                'support_comment', 'a.support_comment',
                'documentation', 'a.documentation',
                'documentation_comment', 'a.documentation_comment',
                'value_for_money', 'a.value_for_money',
                'value_for_money_comment', 'a.value_for_money_comment',
                'overall_score', 'a.overall_score',
                'used_for', 'a.used_for',
                // 'flagged' and 'ip_address' are deliberately absent. filter_fields is the
                // allowlist ListModel validates "list_fullordering" against, so leaving them in
                // would let anyone order the public review list by the moderation flag or by the
                // reviewer's IP address with a hand-made URL, whatever the filter form offers.
                'state', 'a.state',
                'created_on', 'a.created_on',
                'created_by', 'a.created_by',
                'ordering', 'a.ordering',
            ];
        }

        parent::__construct($config);
    }




    /**
     * Method to autopopulate the model state.
     *
     * Note. Calling getState in this method will result in recursion.
     *
     * @param string $ordering  Elements order
     * @param string $direction Order direction
     *
     * @return void
     *
     * @since  4.0.0
     * @throws Exception
     *
     * @throws Exception
     */
    protected function populateState($ordering = null, $direction = null): void
    {
        // List state information.
        parent::populateState('a.id', 'DESC');

        $app  = Factory::getApplication();
        $list = $app->getUserState($this->context . '.list');

        $value         = $app->getUserState($this->context . '.list.limit', $app->get('list_limit', 25));
        $list['limit'] = $value;

        $this->setState('list.limit', $value);

        $value = $app->getInput()->get('limitstart', 0, 'uint');
        $this->setState('list.start', $value);

        $ordering  = $this->getUserStateFromRequest($this->context . '.filter_order', 'filter_order', 'a.id');
        $direction = strtoupper((string) $this->getUserStateFromRequest($this->context . '.filter_order_Dir', 'filter_order_Dir', 'DESC'));

        if (!empty($ordering) || !empty($direction)) {
            $list['fullordering'] = $ordering . ' ' . $direction;
        }

        $app->setUserState($this->context . '.list', $list);



        $context = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
        $this->setState('filter.search', $context);

        // Split context into component and optional section
        $parts = FieldsHelper::extract($context);

        if ($parts) {
            $this->setState('filter.component', $parts[0]);
            $this->setState('filter.section', $parts[1]);
        }
    }

    /**
     * Build an SQL query to load the list data.
     *
     * @return QueryInterface|string
     *
     * @since 4.0.0
     */
    protected function getListQuery(): QueryInterface|string
    {
        // Create a new query object.
        $db    = $this->getDatabase();
        $query = $db->getQuery(true);

        // Select the required fields from the table.
        $query->select(
            $this->getState(
                'list.select',
                'DISTINCT a.*'
            )
        );

        $query->from($db->quoteName('#__jed_reviews', 'a'));

        // Join over the users for the checked out user.
        $query->select('uc.name AS uEditor');
        $query->leftJoin($db->quoteName('#__users', 'uc'), 'uc.id=a.checked_out');
        // Join over the foreign key 'extension_id'
        $query->select('`#__jed_extensions_3715042`.`name` AS extensions_fk_value_3715042');
        $query->leftJoin($db->quoteName('#__jed_extensions', '#__jed_extensions_3715042'), '#__jed_extensions_3715042.`id` = a.`extension_id`');

        // Join over the created by field 'created_by'
        $query->leftJoin($db->quoteName('#__users', 'created_by'), 'created_by.id = a.created_by');

        // Moderated reviews only, plus the current user's own. This model previously had no
        // state filter at all, so unpublished reviews were listed publicly.
        $query->where(JedHelper::getReviewVisibilityCondition($db));

        // Filter by search in title
        $search = $this->getState('filter.search');

        if (!empty($search)) {
            if (stripos((string) $search, 'id:') === 0) {
                $query->where('a.id = ' . (int) substr((string) $search, 3));
            } else {
                $search = $db->Quote('%' . $db->escape($search, true) . '%');
                $query->where('( a.title LIKE ' . $search . ' )');
            }
        }




        // Add the list ordering clause.
        $orderCol  = $this->state->get('list.ordering', 'a.id');
        $orderDirn = $this->state->get('list.direction', 'DESC');

        if ($orderCol && $orderDirn) {
            $query->order($db->escape($orderCol . ' ' . $orderDirn));
        }

        return $query;
    }

    /**
     * Method to get an array of data items
     *
     * @return mixed An array of data on success, false on failure.
     * @since  4.0.0
     */
    public function getItems(): mixed
    {
        $items = parent::getItems();
        $db    = $this->getDatabase();

        foreach ($items as $item) {
            if (isset($item->extension_id)) {
                $values    = explode(',', $item->extension_id);
                $textValue = [];

                foreach ($values as $value) {
                    $query = $db->getQuery(true);
                    $query
                        ->select('`#__jed_extensions_3715042`.`name`')
                        ->from($db->quoteName('#__jed_extensions', '#__jed_extensions_3715042'))
                        ->where($db->quoteName('#__jed_extensions_3715042.id') . ' = ' . $db->quote($db->escape($value)));

                    $db->setQuery($query);
                    $results = $db->loadObject();

                    if ($results) {
                        $textValue[] = $results->name;
                    }
                }

                $item->extension_id = !empty($textValue) ? implode(', ', $textValue) : $item->extension_id;
            }
        }

        return $items;
    }

    /**
     * Overrides the default function to check Date fields format, identified by
     * "_dateformat" suffix, and erases the field if it's not correct.
     *
     * @return mixed
     * @throws Exception
     * @since  4.0.0
     */
    protected function loadFormData(): mixed
    {
        $app              = Factory::getApplication();
        $filters          = $app->getUserState($this->context . '.filter', []);
        $error_dateformat = false;

        foreach ($filters as $key => $value) {
            if (strpos((string) $key, '_dateformat') && !empty($value) && $this->isValidDate($value) == null) {
                $filters[$key]    = '';
                $error_dateformat = true;
            }
        }

        if ($error_dateformat) {
            $app->enqueueMessage(Text::_("COM_JED_SEARCH_FILTER_DATE_FORMAT"), "warning");
            $app->setUserState($this->context . '.filter', $filters);
        }

        return parent::loadFormData();
    }

    /**
     * Checks if a given date is valid and in a specified format (YYYY-MM-DD)
     *
     * @param string $date Date to be checked
     *
     * @return bool
     * @since  4.0.0
     */
    private function isValidDate(string $date): bool
    {
        $date = str_replace('/', '-', $date);
        return (date_create($date)) ? Factory::getDate($date)->format("Y-m-d") : false;
    }
}
