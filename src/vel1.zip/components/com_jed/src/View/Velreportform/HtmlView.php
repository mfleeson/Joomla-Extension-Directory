<?php

/**
 * @package JED
 *
 * @subpackage VEL
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jed\Component\Jed\Site\View\Velreportform;

// No direct access
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Exception;
use Jed\Component\Jed\Site\Helper\JedHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\Registry\Registry;
use stdClass;

/**
 * View class for a VEL Report Form.
 *
 * @since 4.0.0
 */
class HtmlView extends BaseHtmlView
{
    /**
     * The model state
     *
     * @var   Registry
     * @since 4.0.0
     */
    protected Registry $state;

    /**
     * The item to be viewed
     *
     * @var   stdClass
     * @since 4.0.0
     */
    protected mixed $item;

    /**
     * Form with settings
     *
     * @var   Form|null
     * @since 4.0.0
     */
    protected mixed $form;

    /**
     * Get the Params
     *
     * @var   Registry
     * @since 4.0.0
     */
    protected Registry $params;
    /**
     * Does user have permission to save form
     *
     * @var   bool
     * @since 4.0.0
     */
    protected bool $canSave;
    /**
     * Is the form read only
     *
     * @var   bool
     * @since 4.0.0
     */
    protected bool $read_only = false;

    /**
     * Prepares the document
     *
     * @return void
     *
     * @since  4.0.0
     * @throws Exception
     */
    protected function prepareDocument(): void
    {
        $app   = Factory::getApplication();
        $menus = $app->getMenu();

        // Because the application sets a default page title,
        // we need to get it from the menu item itself
        $menu = $menus->getActive();

        if ($menu) {
            $this->params->set('page_heading', $this->params->get('page_title', $menu->title));
        } else {
            $this->params->set('page_heading', Text::_('COM_JED_DEFAULT_PAGE_TITLE'));
        }

        $title = $this->params->get('page_title', '');

        if (empty($title)) {
            $title = $app->get('sitename');
        } elseif ($app->get('sitename_pagetitles', 0) == 1) {
            $title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
        } elseif ($app->get('sitename_pagetitles', 0) == 2) {
            $title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
        }

        $this->getDocument()->setTitle($title);

        if ($this->params->get('menu-meta_description')) {
            $this->getDocument()->setDescription($this->params->get('menu-meta_description'));
        }

        if ($this->params->get('menu-meta_keywords')) {
            $this->getDocument()->setMetadata('keywords', $this->params->get('menu-meta_keywords'));
        }

        if ($this->params->get('robots')) {
            $this->getDocument()->setMetadata('robots', $this->params->get('robots'));
        }
    }

    /**
     * Display the view
     *
     * @param string $tpl Template name
     *
     * @return void
     *
     * @since  4.0.0
     * @throws Exception
     */
    public function display($tpl = null): void
    {
        $app   = Factory::getApplication();
        $model = $this->getModel();
        $model->setUseExceptions(true);
        try {
            $this->state   = $model->getState();
            $this->item    = $model->getItem();
            $this->params  = $app->getParams('com_jed');
            $this->canSave = JedHelper::canSave();
            $this->form    = $model->getForm();
            if (!$this->item == false) {
                if ($this->item->id > 0) {
                    $this->read_only = true;
                }
            }
        } catch (\Exception $e) {
            throw new GenericDataException($e->getMessage(), 500, $e);
        }


        $this->prepareDocument();

        parent::display($tpl);
    }
}
