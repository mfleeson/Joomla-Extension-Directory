<?php

/**
 * @package JED
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jed\Component\Jed\Site\View\Category;

// No direct access
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Exception;
use Joomla\CMS\MVC\View\CategoryView;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

/**
 * View class for a list of Extensions.
 *
 * @since 4.0.0
 */
class HtmlView extends CategoryView
{
    /**
     * Title of the category being viewed.
     *
     * @var   string
     * @since 4.0.0
     */
    protected string $categoryTitle = '';

    /**
     * Rendered breadcrumb trail from the root down to the category being viewed.
     *
     * @var   string
     * @since 4.0.0
     */
    protected string $categoryHierarchy = '';

    /**
     * Display the view
     *
     * @param string $tpl Template name
     *
     * @return void
     *
     * @throws Exception
     *
     * @since 4.0.0
     */
    public function display($tpl = null): void
    {

        /* @var $model \Jed\Component\Jed\Site\Model\CategoryModel */
        /* @var $app \Joomla\CMS\Application\SiteApplication */

        $app   = Factory::getApplication();
        $model = $this->getModel();

        // Get data from the model.
        $this->items         = $model->getItems();
        $this->pagination    = $model->getPagination();

        $this->state = $model->getState();


        $this->children = $model->getChildren();

        // The heading used to be read from $this->items[0], which a category holding no listings
        // of its own does not have - three warnings and an empty heading. Both come from the
        // category itself now, which exists either way.
        $category                = $model->getCurrentCategory();
        $this->categoryTitle     = $category->title ?? Text::_('COM_JED_EXTENSIONS');
        $this->categoryHierarchy = $category ? $model->getCategoryHierarchy((int) $category->id) : '';

        $this->params     = $app->getParams();

        $this->prepareDocument();
        parent::display($tpl);
    }

    /**
     * Prepares the document
     *
     * @return void
     *
     * @since 4.0.0
     *
     * @throws Exception
     */
    protected function prepareDocument(): void
    {

        /* @var $app \Joomla\CMS\Application\SiteApplication */

        $app   = Factory::getApplication();
        $menus = $app->getMenu();

        // Because the application sets a default page title,
        // we need to get it from the menu item itself
        $menu = $menus->getActive();

        if ($menu) {
            $this->params->def('page_heading', $this->params->get('page_title', $menu->title));
        } else {
            $this->params->def('page_heading', Text::_('COM_JED_DEFAULT_PAGE_TITLE'));
        }

        $title = $this->params->get('page_title', '');

        if (empty($title)) {
            $title = $app->get('sitename');
        } elseif ($app->get('sitename_pagetitles', 0) == 1) {
            $title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
        } elseif ($app->get('sitename_pagetitles', 0) == 2) {
            $title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
        }

        $this->getDocument()->setTitle($title);

        if ($this->params->get('menu-meta_description')) {
            $this->getDocument()->setDescription($this->params->get('menu-meta_description'));
        }

        if ($this->params->get('menu-meta_keywords')) {
            $this->getDocument()->setMetadata('keywords', $this->params->get('menu-meta_keywords'));
        }

        if ($this->params->get('robots')) {
            $this->getDocument()->setMetadata('robots', $this->params->get('robots'));
        }


        // Add Breadcrumbs
        $pathway         = $app->getPathway();
        $breadcrumbTitle = Text::_('COM_JED_EXTENSIONS');

        if (!in_array($breadcrumbTitle, $pathway->getPathwayNames())) {
            $pathway->addItem($breadcrumbTitle);
        }
    }

    /**
     * Check if the state is set
     *
     * @param mixed $state State
     *
     * @return bool
     *
     * @since 4.0.0
     */
    public function getState(mixed $state): bool
    {
        return $this->state->{$state} ?? false;
    }
}
