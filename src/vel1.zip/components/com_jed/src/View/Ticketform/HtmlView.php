<?php

/**
 * @package JED
 *
 * @subpackage TICKETS
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc.  <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jed\Component\Jed\Site\View\Ticketform;

// No direct access
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;

// phpcs:enable PSR1.Files.SideEffects

use Jed\Component\Jed\Site\Helper\JedHelper;
use Jed\Component\Jed\Administrator\Enum\TicketType;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\Registry\Registry;

/**
 * View class for a Ticket Form
 *
 * @since 4.0.0
 */
class HtmlView extends BaseHtmlView
{
    /**
     * The model state
     *
     * @var   Registry
     * @since 4.0.0
     */
    protected Registry $state;
    /**
     * The item object
     *
     * @var   object
     * @since 4.0.0
     */
    protected mixed $item;
    /**
     * The Form object
     *
     * @var Form
     *
     * @since 4.0.0
     */
    protected mixed $form;
    /**
     * The components parameters
     *
     * @var Registry
     *
     * @since 4.0.0
     */
    protected Registry $params;
    /**
     * Does user have permission to save form
     *
     * @var   bool
     * @since 4.0.0
     */
    protected bool $canSave;

    /**
     * Prepares the document
     *
     * @return void
     *
     * @since 4.0.0
     *
     * @throws Exception
     */
    protected function prepareDocument(): void
    {
        $app   = Factory::getApplication();
        $menus = $app->getMenu();

        // Because the application sets a default page title,
        // we need to get it from the menu item itself
        $menu = $menus->getActive();

        if ($menu) {
            $this->params->def('page_heading', $this->params->get('page_title', $menu->title));
        } else {
            $this->params->def('page_heading', Text::_('COM_JED_DEFAULT_PAGE_TITLE'));
        }

        $title = $this->params->get('page_title', '');

        if (empty($title)) {
            $title = $app->get('sitename');
        } elseif ($app->get('sitename_pagetitles', 0) == 1) {
            $title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
        } elseif ($app->get('sitename_pagetitles', 0) == 2) {
            $title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
        }

        $this->getDocument()->setTitle($title);

        if ($this->params->get('menu-meta_description')) {
            $this->getDocument()->setDescription($this->params->get('menu-meta_description'));
        }

        if ($this->params->get('menu-meta_keywords')) {
            $this->getDocument()->setMetadata('keywords', $this->params->get('menu-meta_keywords'));
        }

        if ($this->params->get('robots')) {
            $this->getDocument()->setMetadata('robots', $this->params->get('robots'));
        }
    }

    /**
     * Display the view
     *
     * @param string $tpl Template name
     *
     * @return void
     *
     * @since 4.0.0
     *
     * @throws Exception
     */
    public function display($tpl = null): void
    {
        $app = Factory::getApplication();

        $model = $this->getModel();
        $model->setUseExceptions(true);
        $this->state      = $model->getState();
        $this->item       = $model->getItem();
        $this->params     = $app->getParams('com_jed');
        $this->canSave    = JedHelper::canSave();
        $this->form       = $model->getForm();

        $input         = $app->getInput();
        $linked_id     = $input->get('lid', -1, 'int');
        $linked_item   = $input->get('litem', -1, 'int');
        $vr            = $input->get('vr', -1, 'int');

        $this->item->ticket_title = "Submit Ticket";
        if ($linked_id <> -1) {
            $this->item->linked_item_type = $linked_item;
            $this->item->linked_item_id   = $linked_id;
            $this->item->vr               = $vr;
            $ticket_type                  = "Unknown";
            $ticket_selector               = 1;
            if ($linked_item === TicketType::Extension->value) {
                $ticket_type = "Extension";
                $ticket_selector  = 10;
                $this->item->allocated_group = 3; //listing specialist
            }

            if ($linked_item === TicketType::Review->value) {
                $ticket_type = "Review";
                $ticket_selector  = 9;

                $this->item->allocated_group = 4; //review specialist
            }
            $this->item->ticket_category_type = $ticket_selector;
            $this->item->extension_title = JedHelper::getExtensionTitle($vr);

            // A review report names the review; `vr` still carries the extension so the ticket
            // stays attached to the right listing. Without this, two reports about different
            // reviews of the same extension arrive with identical subjects.
            $subject = $linked_item === TicketType::Review->value
                ? (JedHelper::getReviewTitle($linked_id) ?: $this->item->extension_title)
                : $this->item->extension_title;

            $this->item->ticket_title = "Reporting " . $ticket_type . ' - ' . $subject;

            // ticket_title was computed here and consumed nowhere - the form rendered an empty
            // subject box, so the ticket queue filled with untitled reports and a moderator had
            // to open each one to see what it was about. Push it into the field the form
            // actually renders, without overwriting anything the reporter has already typed.
            if ($this->form instanceof Form && $this->form->getValue('ticket_subject') === null) {
                $this->form->setValue('ticket_subject', null, $this->item->ticket_title);
            }
        }



        $this->prepareDocument();

        parent::display($tpl);
    }
}
