<?php

/**
 * @package JED
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Jed\Component\Jed\Site\Helper\JedHelper;
use Jed\Component\Jed\Administrator\Enum\TicketType;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Session\Session;

/** @var \Jed\Component\Jed\Site\View\Reviews\HtmlView $this */

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');


$user       = $this->getCurrentUser();
$userId     = $user->id;
$listOrder  = $this->state->get('list.ordering', '');
$listDirn   = $this->state->get('list.direction');
$canCreate  = $user->authorise('core.create', 'com_jed');
$canEdit    = $user->authorise('core.edit', 'com_jed');
$canCheckin = $user->authorise('core.manage', 'com_jed');
$canChange  = $user->authorise('core.edit.state', 'com_jed');
$canDelete  = $user->authorise('core.delete', 'com_jed');

// Import CSS
try {
    $wa = Factory::getApplication()->getDocument()->getWebAssetManager();
} catch (Exception) {
}
$wa->useStyle('com_jed.list');
?>

<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post"
      name="adminForm" id="adminForm">
    <?php if (!empty($this->filterForm)) {
        echo LayoutHelper::render('joomla.searchtools.default', ['view' => $this]);
    } ?>
    <div class="table-responsive">
        <table class="table table-striped" id="reviewList">
            <thead>
            <tr>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_GENERAL_ID_LABEL', 'a.id', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_EXTENSION', 'a.extension_id', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_GENERAL_TITLE_LABEL', 'a.title', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'JALIAS', 'a.alias', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_REVIEWS_BODY_LABEL', 'a.body', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_REVIEWS_FUNCTIONALITY_LABEL', 'a.functionality', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_REVIEWS_EASE_OF_USE_LABEL', 'a.ease_of_use', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_GENERAL_SUPPORT_LABEL', 'a.support', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_GENERAL_SUPPORT_LABEL_COMMENT', 'a.support_comment', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_EXTENSION_DOCUMENTATION_LABEL', 'a.documentation', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_EXTENSION_DOCUMENTATION_LABEL_COMMENT', 'a.documentation_comment', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_REVIEWS_VALUE_FOR_MONEY_LABEL', 'a.value_for_money', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_REVIEWS_VALUE_FOR_MONEY_LABEL_COMMENT', 'a.value_for_money_comment', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_REVIEWS_OVERALL_SCORE_LABEL', 'a.overall_score', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_REVIEWS_USED_FOR_LABEL', 'a.used_for', $listDirn, $listOrder); ?>
                    </th>

                    <?php
                    // The flag and the reviewer's IP address used to be two more sortable columns
                    // here. This is the public review list - no login required - so it published
                    // the IP address of every reviewer in the directory, 36,171 of them in the
                    // imported stock. They are moderation data, the same three fields
                    // reviewform.xml now keeps in its own fieldset, and they belong in the
                    // administrator's review list and nowhere else.
                    ?>
                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'JPUBLISHED', 'a.state', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'COM_JED_GENERAL_CREATED_ON_LABEL', 'a.created_on', $listDirn, $listOrder); ?>
                    </th>

                    <th class=''>
                        <?php echo HTMLHelper::_('grid.sort', 'JGLOBAL_FIELD_CREATED_BY_LABEL', 'a.created_by', $listDirn, $listOrder); ?>
                    </th>

                        <?php if ($canEdit || $canDelete) : ?>
                    <th class="center">
                            <?php echo Text::_('COM_JED_GENERAL_ACTIONS_LABEL'); ?>
                    </th>
                        <?php endif; ?>

            </tr>
            </thead>
            <tfoot>
            <tr>
                <td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
                    <?php echo $this->pagination->getListFooter(); ?>
                </td>
            </tr>
            </tfoot>
            <tbody>
            <?php foreach ($this->items as $i => $item) : ?>
                <?php $canEdit = $user->authorise('core.edit', 'com_jed'); ?>
                <?php if (!$canEdit && $user->authorise('core.edit.own', 'com_jed')) : ?>
                    <?php $canEdit = $this->getCurrentUser()->id == $item->created_by; ?>
                <?php endif; ?>

                <tr class="row<?php echo $i % 2; ?>">

                    <td>
                        <?php echo $item->id; ?>
                    </td>
                    <td>
                        <?php echo $item->extension_id; ?>
                    </td>
                    <td>
                        <?php $canCheckin = $this->getCurrentUser()->authorise('core.manage', 'com_jed.' . $item->id) || $item->checked_out == $this->getCurrentUser()->id; ?>
                        <?php if ($canCheckin && $item->checked_out > 0) : ?>
                            <a href="<?php echo Route::_('index.php?option=com_jed&task=review.checkin&id=' . $item->id . '&' . Session::getFormToken() . '=1'); ?>">
                            <?php echo HTMLHelper::_('jgrid.checkedout', $i, $item->uEditor, $item->checked_out_time, 'review.', false); ?></a>
                        <?php endif; ?>
                        <a href="<?php echo Route::_('index.php?option=com_jed&view=review&id=' . (int) $item->id); ?>">
                            <?php echo $this->escape($item->title); ?></a>
                        <?php
                        // Same report entry point as the single-review view, per row. Logged-in
                        // readers only, and not on one's own review.
                        if (JedHelper::isLoggedIn() && (int) $item->created_by !== (int) $user->id) :
                            $reportUrl = Route::_(
                                'index.php?option=com_jed&view=ticketform'
                                . '&litem=' . TicketType::Review->value
                                . '&lid=' . (int) $item->id
                                . '&vr=' . (int) $item->extension_id
                            );
                            ?>
                            <a href="<?php echo $reportUrl; ?>" class="small text-muted ms-2">
                                <span class="icon-flag" aria-hidden="true"></span>
                                <?php echo Text::_('COM_JED_REVIEW_REPORT_LABEL'); ?>
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo $item->alias; ?>
                    </td>
                    <td>
                        <?php echo $item->body; ?>
                    </td>
                    <td>
                        <?php echo number_format((float) $item->functionality, 1); ?>
                    </td>
                    <td>
                        <?php echo number_format((float) $item->ease_of_use, 1); ?>
                    </td>
                    <td>
                        <?php echo number_format((float) $item->support, 1); ?>
                    </td>
                    <td>
                        <?php echo $item->support_comment; ?>
                    </td>
                    <td>
                        <?php echo number_format((float) $item->documentation, 1); ?>
                    </td>
                    <td>
                        <?php echo $item->documentation_comment; ?>
                    </td>
                    <td>
                        <?php echo number_format((float) $item->value_for_money, 1); ?>
                    </td>
                    <td>
                        <?php echo $item->value_for_money_comment; ?>
                    </td>
                    <td>
                        <?php echo number_format((float) $item->overall_score, 1); ?>
                    </td>
                    <td>
                        <?php echo $item->used_for; ?>
                    </td>
                    <td>
                        <?php echo $item->state; ?>
                    </td>
                    <td>
                        <?php echo $item->created_on; ?>
                    </td>
                    <td>
                                <?php echo $this->getCurrentUser()->name; ?>
                    </td>
                    <?php if ($canEdit || $canDelete) : ?>
                        <td class="center">
                            <?php $canCheckin = $this->getCurrentUser()->authorise('core.manage', 'com_jed.' . $item->id) || $item->checked_out == $this->getCurrentUser()->id; ?>

                            <?php if ($canEdit && $item->checked_out == 0) : ?>
                                <a href="<?php echo Route::_('index.php?option=com_jed&task=review.edit&id=' . $item->id, false, 2); ?>" class="btn btn-mini" type="button"><i class="icon-edit" ></i></a>
                            <?php endif; ?>
                            <?php if ($canDelete) : ?>
                                <a href="<?php echo Route::_('index.php?option=com_jed&task=reviewform.remove&id=' . $item->id, false, 2); ?>" class="btn btn-mini delete-button" type="button"><i class="icon-trash" ></i></a>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>

                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($canCreate) : ?>
        <a href="<?php echo Route::_('index.php?option=com_jed&task=reviewform.edit&id=0', false, 0); ?>"
           class="btn btn-success btn-small"><i
                class="icon-plus"></i>
            <?php echo Text::_('JGLOBAL_FIELD_ADD'); ?></a>
    <?php endif; ?>

    <input type="hidden" name="task" value=""/>
    <input type="hidden" name="boxchecked" value="0"/>
    <input type="hidden" name="filter_order" value=""/>
    <input type="hidden" name="filter_order_Dir" value=""/>
    <?php echo HTMLHelper::_('form.token'); ?>
</form>

