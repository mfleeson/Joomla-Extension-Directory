-- This file must be safe to run twice (P1-30). Joomla only runs it on the `install` route, but
-- that route is reached again after an uninstall, and after an uninstall the tables are still
-- there - uninstall.mysql.utf8.sql no longer drops them. So: CREATE TABLE IF NOT EXISTS, and
-- INSERT IGNORE for the seed rows. Nothing here may destroy data.
--
-- The DROP TABLE statements that used to precede every CREATE now live in reset.mysql.utf8.sql,
-- which no manifest references. See that file for the developer reset workflow.
--
-- Schema changes after go-live do NOT belong in this file. They belong in
-- sql/updates/mysql/<version>.sql, which is what Joomla runs on the `update` route; this file is
-- then updated to match so a fresh install produces the same schema.
--
-- Foreign keys (added in 4.0.1) are scoped to com_jed's own tables, anchored on
-- `#__jed_extensions`.`id` and, once, on `#__jed_extensions_history`.`id`. Deliberately absent:
-- every `catid` (references Joomla core `#__categories`, which core components never FK into
-- either) and every `owner`/`created_by`/`modified_by`/`*_user_id`/`checked_by`/`set_by` column
-- (references core `#__users`). A RESTRICT there would block deleting a user who ever touched a
-- listing; CASCADE would silently delete a developer's whole catalogue when their account is
-- removed; SET NULL cannot apply to the columns that are NOT NULL. None of the three is safe, so
-- those stay plain, unconstrained indexes, same as every other Joomla component.
--
-- FOREIGN_KEY_CHECKS is off for the whole file so table order below is free; every FK here would
-- also resolve without it, since every referenced table is created earlier in this file.

SET FOREIGN_KEY_CHECKS = 0;


CREATE TABLE IF NOT EXISTS `#__jed_extensions`
(
	`id`                     int unsigned    NOT NULL AUTO_INCREMENT,
	`name`                   varchar(255)    NOT NULL DEFAULT '',
	`alias`                  varchar(255)    NOT NULL DEFAULT '',
	`catid`                  int unsigned    NOT NULL,
	`owner`                  int unsigned    NOT NULL,
	`state`                  tinyint(1)      NOT NULL DEFAULT '0',
	`approved`               tinyint(1)      DEFAULT '0',
	`approved_time`          datetime        DEFAULT NULL,
	-- The moderation verdict (P1-02): approved_time NULL means "not decided yet", set together
	-- with approved = 1 means approved, set together with approved = 0 means rejected.
	-- approved_reason carries a code from #__jed_block_reasons - one vocabulary for rejections
	-- and blocks - and approved_notes the free text sent to the developer with it.
	`approved_by`            int unsigned    DEFAULT NULL,
	`approved_notes`         text,
	`approved_reason`        varchar(255)    DEFAULT '',
	`intro`                  text,
	`description`            mediumtext,
	`license`                varchar(255)    DEFAULT '',
	-- The developer's own licence/terms page. `license` above is the licence *name*
	-- ("GPLv2", "Commercial"); this is where it can be read. 11,223 JED3 rows carry one,
	-- which is why the detail page's Licence button gets a real column rather than being
	-- dropped (P1-07).
	`license_url`            varchar(255)    DEFAULT '',
	`requires_registration`  tinyint(1)      NOT NULL DEFAULT '0',
	`type`                   enum('free', 'paid', 'freemium', 'cloud') DEFAULT 'free',
	`extension_types`        varchar(255)    DEFAULT '',
	`created`                datetime,
	`created_by`             int unsigned    NOT NULL,
	`modified`               datetime        DEFAULT NULL,
	`modified_by`            int unsigned    NULL,
	`checked_out`            int unsigned,
	`checked_out_time`       datetime        DEFAULT NULL,
	`extension_version`      varchar(50)     DEFAULT '',
	`entry_version`          int,
	`joomla_versions`        varchar(255)    DEFAULT '',
	`download_url`           varchar(255)    DEFAULT '',
	`support_url`            varchar(255)    DEFAULT '',
	`demo_url`               varchar(255)    DEFAULT '',
	`documentation_url`      varchar(255)    DEFAULT '',
	`git_url`                varchar(255)    DEFAULT '',
	`internal_download_url`  varchar(255)    DEFAULT '',
	`download_key`           varchar(255)    DEFAULT '',
	`uses_updater`           tinyint(1)      NOT NULL DEFAULT '0',
	`update_url`             varchar(255)    DEFAULT '',
	`last_update_check`      datetime        DEFAULT NULL,
	`last_update_check_error` varchar(255)   DEFAULT NULL,
	`developer_url`          varchar(255)    DEFAULT '',
	`developer_email`        varchar(255)    DEFAULT '',
	`changelog_url`          varchar(255)    DEFAULT '',
	`score_overall`          decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_functionality`    decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_ease_of_use`      decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_support`          decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_documentation`    decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_value_for_money`  decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_count`            int unsigned    NOT NULL DEFAULT '0',
	`popular`                tinyint(1)      NOT NULL DEFAULT '0',
	`logo`                   varchar(255)    DEFAULT '',
	`video`                  varchar(255)    DEFAULT '',
	-- The raw value above is kept as the developer typed it; these two are what P1-11's
	-- parser made of it. Provider plus id rather than a ready-made embed URL: the card view
	-- wants a thumbnail without an iframe, and that needs the id on its own. NULL means the
	-- value could not be recognised as a video, which is a result and not a gap - those rows
	-- are what the clean-up report lists.
	`video_provider`         varchar(20)     DEFAULT NULL,
	`video_id`               varchar(255)    DEFAULT NULL,
	`internal_note`          mediumtext,
	-- Blocking and soft delete are separate carriers from `state` on purpose (4.8, P1-01):
	-- `state` belongs to the developer, `blocked` to the JED team. Mapped onto one column, a
	-- developer could lift a block by republishing. block_reason_text is internal - only the
	-- reason code's title is ever shown publicly.
	`blocked`                tinyint(1)      NOT NULL DEFAULT '0',
	`block_reason_code`      varchar(32)     DEFAULT NULL,
	`block_reason_text`      text,
	`blocked_by`             int unsigned    DEFAULT NULL,
	`blocked_time`           datetime        DEFAULT NULL,
	`deleted`                tinyint(1)      NOT NULL DEFAULT '0',
	`deleted_by`             int unsigned    DEFAULT NULL,
	`deleted_time`           datetime        DEFAULT NULL,
	-- The two linked-extension relations (P1-23). Single columns, not mapping tables: 8.5
	-- assumed both were m:n, and P0-03 measured MAX(rows per extension) = 1 for both, so a
	-- column carries the JED3 stock losslessly and a join table would only add a way to
	-- disagree with itself.
	--
	-- variant_of_id is the free/paid pairing ("Foobar Lite" / "Foobar Pro"). The relation is
	-- symmetric but stored ONCE and queried in both directions - JED3 stored it twice for 75
	-- of its 938 pairs and once for the rest, which is exactly the inconsistency storing it
	-- once cannot have.
	--
	-- parent_id is "this extension extends that one" and is NOT symmetric: 1,070 add-ons point
	-- at 191 products, VirtueMart alone at 268. parent_confirmed is a JED team carrier, kept
	-- apart from parent_id for the same reason `blocked` is kept apart from `state` (4.8): the
	-- developer asserts what their own add-on extends, the team decides whether that assertion
	-- also gets to appear on somebody else's listing. It is deliberately absent from
	-- #__jed_extensions_history, so approving a developer's revision can never confirm it.
	--
	-- NULL, never 0, for "no relation" (8.14): 0 is not an extension id and a column that
	-- means "unset" by pointing at a row that cannot exist is how JED3's own tables read.
	`variant_of_id`          int unsigned    DEFAULT NULL,
	`parent_id`              int unsigned    DEFAULT NULL,
	`parent_confirmed`       tinyint(1)      NOT NULL DEFAULT '0',
	PRIMARY KEY (`id`),
	KEY `IDX_jed_extensions_catid` (`catid`),
	KEY `IDX_jed_extensions_owner` (`owner`),
	KEY `IDX_jed_extensions_state` (`state`),
	KEY `IDX_jed_extensions_visibility` (`approved`, `state`, `blocked`, `deleted`),
	KEY `IDX_jed_extensions_alias` (`alias`),
	-- Both relations are read backwards far more often than forwards: one listing's own
	-- parent is a primary-key lookup, "everything that extends this one" is not.
	KEY `IDX_jed_extensions_variant_of` (`variant_of_id`),
	KEY `IDX_jed_extensions_parent` (`parent_id`, `parent_confirmed`),
	-- SET NULL, not CASCADE: both columns already use NULL to mean "no relation" (see above), so
	-- deleting the target listing removes exactly the claim, not the listing making it.
	CONSTRAINT `FK_jed_extensions_variant_of_id` FOREIGN KEY (`variant_of_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE SET NULL,
	CONSTRAINT `FK_jed_extensions_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- A revision of a listing: a full copy of the #__jed_extensions row as it stood, plus the two
-- columns that make it a revision (`extension_id`, `active`).
--
-- "Full copy" has three deliberate exceptions, and this is the record of that decision (P1-30,
-- Validation Report 3.4). They are asserted by tests/unit/Schema/SchemaUpdatePathTest.php, so
-- any *other* column added to #__jed_extensions from here on has to be mirrored below or CI
-- fails - which is the point: a column that is not mirrored is a column a rollback silently
-- reverts to a wrong value.
--
--   entry_version            A pointer from the live row *into this table* - the id of the
--                            revision currently shown. Copying it into a revision would be a
--                            self-reference, and restoring an old one would point the listing
--                            at a revision that is not the one being restored.
--   last_update_check        Results of the automated update probe (P1-08). They describe the
--   last_update_check_error  developer's update server at a moment in time, not the listing's
--                            content. A rollback must not resurrect a stale probe result, and a
--                            probe must not create a revision.
--
-- ExtensionVersionUpdater::applyUpdate() unsets exactly these three when it copies a row.
CREATE TABLE IF NOT EXISTS `#__jed_extensions_history`
(
	`id`                     int unsigned    NOT NULL AUTO_INCREMENT,
	`extension_id`           int unsigned    NOT NULL,
	`active`                 tinyint(1)      NOT NULL DEFAULT '0',
	`name`                   varchar(255)    NOT NULL DEFAULT '',
	`alias`                  varchar(255)    NOT NULL DEFAULT '',
	`catid`                  int unsigned    NOT NULL,
	`owner`                  int unsigned    NOT NULL,
	`state`                  tinyint(1)      NOT NULL DEFAULT '0',
	`approved`               tinyint(1)      DEFAULT '0',
	`approved_time`          datetime        DEFAULT NULL,
	-- The moderation verdict (P1-02): approved_time NULL means "not decided yet", set together
	-- with approved = 1 means approved, set together with approved = 0 means rejected.
	-- approved_reason carries a code from #__jed_block_reasons - one vocabulary for rejections
	-- and blocks - and approved_notes the free text sent to the developer with it.
	`approved_by`            int unsigned    DEFAULT NULL,
	`approved_notes`         text,
	`approved_reason`        varchar(255)    DEFAULT '',
	`intro`                  text,
	`description`            mediumtext,
	`license`                varchar(255)    DEFAULT '',
	-- The developer's own licence/terms page. `license` above is the licence *name*
	-- ("GPLv2", "Commercial"); this is where it can be read. 11,223 JED3 rows carry one,
	-- which is why the detail page's Licence button gets a real column rather than being
	-- dropped (P1-07).
	`license_url`            varchar(255)    DEFAULT '',
	`requires_registration`  tinyint(1)      NOT NULL DEFAULT '0',
	`type`                   enum('free', 'paid', 'freemium', 'cloud') DEFAULT 'free',
	`extension_types`        varchar(255)    DEFAULT '',
	`created`                datetime,
	`created_by`             int unsigned    NOT NULL,
	`modified`               datetime        DEFAULT NULL,
	`modified_by`            int unsigned    NULL,
	`checked_out`            int unsigned,
	`checked_out_time`       datetime        DEFAULT NULL,
	`extension_version`      varchar(50)     DEFAULT '',
	`joomla_versions`        varchar(255)    DEFAULT '',
	`download_url`           varchar(255)    DEFAULT '',
	`support_url`            varchar(255)    DEFAULT '',
	`demo_url`               varchar(255)    DEFAULT '',
	`documentation_url`      varchar(255)    DEFAULT '',
	`git_url`                varchar(255)    DEFAULT '',
	`internal_download_url`  varchar(255)    DEFAULT '',
	`download_key`           varchar(255)    DEFAULT '',
	`uses_updater`           tinyint(1)      NOT NULL DEFAULT '0',
	`update_url`             varchar(255)    DEFAULT '',
	`developer_url`          varchar(255)    DEFAULT '',
	`developer_email`        varchar(255)    DEFAULT '',
	`changelog_url`          varchar(255)    DEFAULT '',
	`score_overall`          decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_functionality`    decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_ease_of_use`      decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_support`          decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_documentation`    decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_value_for_money`  decimal(3, 2)   NOT NULL DEFAULT '0.00',
	`score_count`            int unsigned    NOT NULL DEFAULT '0',
	`popular`                tinyint(1)      NOT NULL DEFAULT '0',
	`logo`                   varchar(255)    DEFAULT '',
	`video`                  varchar(255)    DEFAULT '',
	-- The raw value above is kept as the developer typed it; these two are what P1-11's
	-- parser made of it. Provider plus id rather than a ready-made embed URL: the card view
	-- wants a thumbnail without an iframe, and that needs the id on its own. NULL means the
	-- value could not be recognised as a video, which is a result and not a gap - those rows
	-- are what the clean-up report lists.
	`video_provider`         varchar(20)     DEFAULT NULL,
	`video_id`               varchar(255)    DEFAULT NULL,
	`internal_note`          mediumtext,
	-- Mirrored from #__jed_extensions. This is where the block history lives: every block and
	-- unblock writes a revision, so who blocked what, when, under which code and with which
	-- internal note is answerable from the revision list without a dedicated log table.
	`blocked`                tinyint(1)      NOT NULL DEFAULT '0',
	`block_reason_code`      varchar(32)     DEFAULT NULL,
	`block_reason_text`      text,
	`blocked_by`             int unsigned    DEFAULT NULL,
	`blocked_time`           datetime        DEFAULT NULL,
	`deleted`                tinyint(1)      NOT NULL DEFAULT '0',
	`deleted_by`             int unsigned    DEFAULT NULL,
	`deleted_time`           datetime        DEFAULT NULL,
	-- The developer's two halves of P1-23. parent_confirmed is not here on purpose: it is the
	-- JED team's verdict on the parent claim, and a revision must not be able to carry one.
	-- ExtensionModel::approve() copies every history column onto the live row, so a column
	-- present here is by definition a column a developer can set.
	`variant_of_id`          int unsigned    DEFAULT NULL,
	`parent_id`              int unsigned    DEFAULT NULL,
	PRIMARY KEY (`id`),
	KEY `IDX_jed_extensions_catid` (`catid`),
	KEY `IDX_jed_extensions_owner` (`owner`),
	KEY `IDX_jed_extensions_state` (`state`),
	KEY `IDX_jed_extensions_alias` (`alias`),
	KEY `IDX_jed_extensions_history_extension_id` (`extension_id`),
	KEY `IDX_jed_extensions_history_extension_id_active` (`extension_id`, `active`),
	-- A revision is only meaningful next to the listing it revises, so it dies with it.
	CONSTRAINT `FK_jed_extensions_history_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `#__jed_extensions_category_map`
(
	`extension_id` int unsigned NOT NULL,
	`catid`        int unsigned NOT NULL,
	PRIMARY KEY (`extension_id`, `catid`),
	KEY `IDX_jed_extensions_category_map_catid` (`catid`),
	CONSTRAINT `FK_jed_extensions_category_map_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- Additional maintainers only. The owner lives in #__jed_extensions.owner and is never
-- duplicated here (8.8) - "owner OR a row in this table" is the permission rule, so a person in
-- both places would be a second, silently divergent record of the same fact. The application
-- enforces it on write; a cross-table condition cannot be a MySQL constraint.
--
-- `state` is the invitation: 0 invited, 1 accepted, -1 declined. Only an accepted row grants
-- anything. The privileges reach far - edit, publish, answer reviews - and the name can appear on
-- the public listing, so being named by somebody else is not enough (P1-03 item 4). This is a
-- single confirmation; the dual one is reserved for ownership transfer, where the stakes differ.
CREATE TABLE IF NOT EXISTS `#__jed_extensions_maintainers`
(
	`extension_id`  int unsigned NOT NULL,
	`user_id`       int unsigned NOT NULL,
	`state`         tinyint(1)   NOT NULL DEFAULT '0',
	`invited_by`    int unsigned DEFAULT NULL,
	`invited_time`  datetime     DEFAULT NULL,
	`accepted_time` datetime     DEFAULT NULL,
	PRIMARY KEY (`extension_id`, `user_id`),
	KEY `IDX_jed_maintainers_user_state` (`user_id`, `state`),
	CONSTRAINT `FK_jed_extensions_maintainers_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `#__jed_extensions_images`
(
	`id`               int unsigned NOT NULL AUTO_INCREMENT,
	`extension_id`     int unsigned NOT NULL,
	`filename`         text,
	`state`            tinyint(1)   DEFAULT '0',
	`ordering`         int          DEFAULT '0',
	`checked_out`      int unsigned,
	`checked_out_time` datetime,
	`created_by`       int unsigned NOT NULL,
	`modified_by`      int unsigned NULL,
	PRIMARY KEY (`id`),
	KEY `FK_jed_extensions_images_extension_id` (`extension_id`),
	KEY `FK_jed_extensions_images_created_by` (`created_by`),
	KEY `FK_jed_extensions_images_modified_by` (`modified_by`),
	CONSTRAINT `FK_jed_extensions_images_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `#__jed_extensions_files`
(
	`id`            int unsigned NOT NULL AUTO_INCREMENT,
	`extension_id`  int unsigned NOT NULL,
	`file`          varchar(255) NOT NULL DEFAULT '',
	`meta`          text,
	`created_by`    int unsigned NOT NULL,
	`modified_by`   int unsigned NULL,
	`originalFile`  varchar(255) NOT NULL DEFAULT '',
	PRIMARY KEY (`id`),
	KEY `FK_jed_extensions_files_extension_id` (`extension_id`),
	KEY `FK_jed_extensions_files_created_by` (`created_by`),
	KEY `FK_jed_extensions_files_modified_by` (`modified_by`),
	CONSTRAINT `FK_jed_extensions_files_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `#__jed_reviews`
(
	`id`                      int unsigned NOT NULL AUTO_INCREMENT,
	`extension_id`            int unsigned NOT NULL,
	`title`                   varchar(400) DEFAULT '',
	`alias`                   varchar(400) DEFAULT NULL,
	`body`                    mediumtext,
	`functionality`           decimal(2,1) DEFAULT NULL,
	`functionality_comment`   text,
	`ease_of_use`             decimal(2,1) DEFAULT NULL,
	`ease_of_use_comment`     text,
	`support`                 decimal(2,1) DEFAULT NULL,
	`support_comment`         text,
	`documentation`           decimal(2,1) DEFAULT NULL,
	`documentation_comment`   text,
	`value_for_money`         decimal(2,1) DEFAULT NULL,
	`value_for_money_comment` text,
	`overall_score`           decimal(2,1) DEFAULT NULL,
	`used_for`                varchar(400) DEFAULT '',
	`version`                 varchar(255) DEFAULT NULL,
	`flagged`                 varchar(255) DEFAULT '0',
	`ip_address`              varchar(255) DEFAULT '',
	`state`                   tinyint(1)   NOT NULL DEFAULT '0',
	`created_on`              datetime     DEFAULT NULL,
	`created_by`              int unsigned NOT NULL,
	`ordering`                int          DEFAULT '0',
	`checked_out`             int unsigned,
	`checked_out_time`        datetime,
	`developer_response`           mediumtext,
	`developer_responded_on`       datetime     DEFAULT NULL,
	`developer_response_published` tinyint(1)   NOT NULL DEFAULT '0',
	PRIMARY KEY (`id`),
	KEY `IDX_jed_reviews_extension_id_created_by` (`extension_id`, `created_by`),
	KEY `FK_jed_reviews_extension_id` (`extension_id`),
	KEY `FK_jed_reviews_created_by` (`created_by`),
	CONSTRAINT `FK_jed_reviews_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `#__jed_favorites`
(
	`id`           int unsigned NOT NULL AUTO_INCREMENT,
	`user_id`      int unsigned NOT NULL,
	`extension_id` int unsigned NOT NULL,
	`created`      datetime     NOT NULL,
	PRIMARY KEY (`id`),
	UNIQUE KEY `UK_jed_favorites_user_id_extension_id` (`user_id`, `extension_id`),
	KEY `FK_jed_favorites_user_id` (`user_id`),
	KEY `FK_jed_favorites_extension_id` (`extension_id`),
	CONSTRAINT `FK_jed_favorites_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- The abuse-prevention layer JED3 grew over years and this code had none of (7.1). Modelled on
-- the legacy `jed_user_access`, plus the audit fields 4.8 asks for everywhere.
--
-- **An absent row means "default privileges, not banned".** There is deliberately no row per
-- user: 14,000 rows that all say "yes to everything" would be a table nobody could read, and
-- every new registration would need one. A row exists only where something was decided.
--
-- The ban is time-limited by design: `banned_from`/`banned_until` are compared against now, so
-- a ban that has run out stops applying by itself. Making that depend on a cleanup job would
-- mean a job that fails silently leaves people banned.
CREATE TABLE IF NOT EXISTS `#__jed_user_access`
(
	`user_id`                 int unsigned NOT NULL,
	`create_listing`          tinyint(1)   NOT NULL DEFAULT '1',
	`edit_listing`            tinyint(1)   NOT NULL DEFAULT '1',
	`update_xml`              tinyint(1)   NOT NULL DEFAULT '1',
	`review`                  tinyint(1)   NOT NULL DEFAULT '1',
	`report`                  tinyint(1)   NOT NULL DEFAULT '1',
	`auto_approve_extensions` tinyint(1)   NOT NULL DEFAULT '0',
	`auto_approve_reviews`    tinyint(1)   NOT NULL DEFAULT '0',
	`banned`                  tinyint(1)   NOT NULL DEFAULT '0',
	`banned_reason`           text,
	`banned_from`             datetime     DEFAULT NULL,
	`banned_until`            datetime     DEFAULT NULL,
	`set_by`                  int unsigned DEFAULT NULL,
	`set_time`                datetime     DEFAULT NULL,
	PRIMARY KEY (`user_id`),
	KEY `IDX_jed_user_access_banned` (`banned`, `banned_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- Barred from reviewing a particular developer or anything in a particular category, rather than
-- barred from reviewing at all. JED3 kept these as two mapping tables; one table with a target
-- type says the same thing and keeps the check to a single query.
CREATE TABLE IF NOT EXISTS `#__jed_user_review_bans`
(
	`user_id`     int unsigned                  NOT NULL,
	`target_type` enum('developer','category')  NOT NULL,
	`target_id`   int unsigned                  NOT NULL,
	`set_by`      int unsigned                  DEFAULT NULL,
	`set_time`    datetime                      DEFAULT NULL,
	PRIMARY KEY (`user_id`, `target_type`, `target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- Advisory only (P1-05 item 8): a match flags, it never blocks. A shared NAT range is not
-- evidence of anything, and treating it as such would lock out a whole office or country.
-- varbinary(16) holds IPv4 and IPv6 alike through INET6_ATON, so one comparison covers both.
CREATE TABLE IF NOT EXISTS `#__jed_suspect_ip_ranges`
(
	`id`          int unsigned  NOT NULL AUTO_INCREMENT,
	`range_start` varbinary(16) NOT NULL,
	`range_end`   varbinary(16) NOT NULL,
	`note`        varchar(255)  DEFAULT NULL,
	`state`       tinyint(1)    NOT NULL DEFAULT '1',
	PRIMARY KEY (`id`),
	KEY `IDX_jed_suspect_ip_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- A transfer is a state over time, so it is a record of its own rather than columns on the
-- extension (8.8.1). The completed row stays: it is the traceability requirement, and it is the
-- only place that records who handed what to whom.
--
-- States: pending -> from_confirmed / to_confirmed -> completed, plus expired, cancelled and
-- forced. Ownership moves only when *both* parties have confirmed, in either order - which is
-- why the two confirmations are two nullable timestamps rather than one flag.
--
-- The tokens are credentials and are stored **hashed only**. Reading this table must not enable
-- a transfer. They are bound to the user id rather than the email address, so changing an
-- address mid-flight does not break a transfer that is already under way.
CREATE TABLE IF NOT EXISTS `#__jed_extension_transfers`
(
	`id`                  int unsigned NOT NULL AUTO_INCREMENT,
	`extension_id`        int unsigned NOT NULL,
	`from_user_id`        int unsigned NOT NULL,
	`to_user_id`          int unsigned NOT NULL,
	`initiated_by`        int unsigned NOT NULL,
	`initiated_time`      datetime     NOT NULL,
	`from_token_hash`     varchar(255) DEFAULT NULL,
	`from_confirmed_time` datetime     DEFAULT NULL,
	`to_token_hash`       varchar(255) DEFAULT NULL,
	`to_confirmed_time`   datetime     DEFAULT NULL,
	`state`               varchar(20)  NOT NULL DEFAULT 'pending',
	`expires`             datetime     NOT NULL,
	`completed_time`      datetime     DEFAULT NULL,
	`cancelled_by`        int unsigned DEFAULT NULL,
	`cancel_reason`       text,
	PRIMARY KEY (`id`),
	KEY `IDX_transfers_extension` (`extension_id`, `state`),
	KEY `IDX_transfers_to_user` (`to_user_id`, `state`),
	KEY `IDX_transfers_expiry` (`state`, `expires`),
	CONSTRAINT `FK_jed_extension_transfers_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- Looking a recipient up by email address tells the person asking whether that address has an
-- account. 8.8.1 weighed hiding that against making the feature unusable - an owner who cannot
-- tell a typo from a missing account is stuck - and chose the clear answer, bounded. This table
-- is the bound: every attempt is recorded with who made it, which turns an anonymous oracle into
-- an attributable one, and the count per window is what the rate limit reads.
--
-- The address is stored hashed. The log has to answer "how many attempts did this user make"
-- and "did they probe the same address repeatedly", and neither question needs the plaintext -
-- keeping a list of addresses somebody guessed at would create the disclosure it exists to bound.
CREATE TABLE IF NOT EXISTS `#__jed_transfer_lookups`
(
	`id`           int unsigned NOT NULL AUTO_INCREMENT,
	`user_id`      int unsigned NOT NULL,
	`email_hash`   varchar(64)  NOT NULL,
	`found`        tinyint(1)   NOT NULL DEFAULT '0',
	`extension_id` int unsigned DEFAULT NULL,
	`created`      datetime     NOT NULL,
	PRIMARY KEY (`id`),
	KEY `IDX_transfer_lookups_user` (`user_id`, `created`),
	KEY `FK_jed_transfer_lookups_extension_id` (`extension_id`),
	-- SET NULL: the log entry itself is the record that matters (P1-18 retention), and it must
	-- outlive the extension it happened to name.
	CONSTRAINT `FK_jed_transfer_lookups_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- The vocabulary a moderation decision is stated in. Codes are data, not code (4.8), so the JED
-- team can add one without a release. `code` is the primary key because it is what
-- #__jed_extensions and its history store, what the knowledge base articles are keyed by, and
-- what the API will carry - a surrogate id would add a join and a second identity for the same
-- thing. Seeded by script.php from the JED3 submission error codes (P0-05), which the ticket
-- mail templates it also seeds already speak.
--
-- The table is named for blocking because `P1-01` introduced it, but `P1-02` deliberately reuses
-- it for submission rejections: a rejection reason and a block reason say the same things to a
-- developer and are keyed by the same knowledge base articles, so one vocabulary is the point.
-- `mail_template` is the #__mail_templates id sent to the developer when a submission is
-- rejected with this code.
CREATE TABLE IF NOT EXISTS `#__jed_block_reasons`
(
	`code`          varchar(32)  NOT NULL,
	`title`         varchar(255) NOT NULL,
	`article_id`    int unsigned DEFAULT NULL,
	`mail_template` varchar(128) DEFAULT NULL,
	`state`         tinyint(1)   NOT NULL DEFAULT '1',
	`ordering`      int          NOT NULL DEFAULT '0',
	PRIMARY KEY (`code`),
	KEY `IDX_jed_block_reasons_state` (`state`, `ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `#__jed_joomla_versions`
(
	`id`         int unsigned NOT NULL AUTO_INCREMENT,
	`label`      varchar(255) NOT NULL,
	`long_label` varchar(50)  NOT NULL,
	`published`  tinyint(1)   NOT NULL DEFAULT '1',
	PRIMARY KEY (`id`),
	KEY `IDX_jed_joomla_versions_published` (`published`),
	KEY `IDX_jed_joomla_versions_label` (`label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO `#__jed_joomla_versions` (`id`, `label`, `long_label`, `published`) VALUES('15','1.5','Joomla 1.5','0');
INSERT IGNORE INTO `#__jed_joomla_versions` (`id`, `label`, `long_label`, `published`) VALUES('25','2.5','Joomla 2.5','0');
INSERT IGNORE INTO `#__jed_joomla_versions` (`id`, `label`, `long_label`, `published`) VALUES('30','3','Joomla 3','1');
INSERT IGNORE INTO `#__jed_joomla_versions` (`id`, `label`, `long_label`, `published`) VALUES('40','4','Joomla 4','1');
INSERT IGNORE INTO `#__jed_joomla_versions` (`id`, `label`, `long_label`, `published`) VALUES('50','5','Joomla 5','1');
INSERT IGNORE INTO `#__jed_joomla_versions` (`id`, `label`, `long_label`, `published`) VALUES('51','5 (b/c)','Joomla 5 using B/C plugin','1');
INSERT IGNORE INTO `#__jed_joomla_versions` (`id`, `label`, `long_label`, `published`) VALUES('60','6','Joomla 6','1');
INSERT IGNORE INTO `#__jed_joomla_versions` (`id`, `label`, `long_label`, `published`) VALUES('61','6 (b/c)','Joomla 6 using B/C plugin','1');


CREATE TABLE IF NOT EXISTS `#__jed_queue_jobs`
(
	`id`             int unsigned NOT NULL AUTO_INCREMENT,
	`type`           varchar(50)  NOT NULL,
	`extension_id`   int unsigned DEFAULT NULL,
	`history_id`     int unsigned DEFAULT NULL,
	`payload`        text,
	`status`         varchar(20)  NOT NULL DEFAULT 'pending',
	`attempts`       tinyint unsigned NOT NULL DEFAULT '0',
	`last_error`     text,
	`result_meta`    text,
	`created`        datetime     NOT NULL,
	`created_by`     int unsigned NOT NULL DEFAULT '0',
	`started_time`   datetime     DEFAULT NULL,
	`finished_time`  datetime     DEFAULT NULL,
	PRIMARY KEY (`id`),
	KEY `IDX_jed_queue_jobs_status` (`status`),
	KEY `IDX_jed_queue_jobs_type` (`type`),
	KEY `IDX_jed_queue_jobs_extension_id` (`extension_id`),
	KEY `FK_jed_queue_jobs_history_id` (`history_id`),
	-- SET NULL on both: a job is a record that the work happened, and must survive its subject
	-- being deleted - a queue table that lost rows on every unrelated delete would be useless
	-- as an audit trail.
	CONSTRAINT `FK_jed_queue_jobs_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE SET NULL,
	CONSTRAINT `FK_jed_queue_jobs_history_id` FOREIGN KEY (`history_id`) REFERENCES `#__jed_extensions_history` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- The result of every URL check the JED has run (P1-08). Three jobs in one table, which is
-- why it exists at all rather than the check being fire-and-forget:
--
--  * the cache. Typing in a form fires a check per field; without a freshness window the JED
--    would hammer a developer's server on every keystroke that survives the debounce.
--  * the record the JED team reads during moderation. "This download link has not answered
--    since March" is a moderation fact, and it is not visible anywhere if the answer only
--    ever reached the browser that asked.
--  * the rate limit. One row per attempt per user is what the per-user bound counts.
--
-- url_hash rather than the URL as the lookup key: the same address is stored in several
-- fields and several listings, and a hash indexes in a fixed width where a varchar(255) with
-- a full index does not. The URL itself is kept next to it because the moderation view has to
-- show what was checked. Results are never public (4.9).
CREATE TABLE IF NOT EXISTS `#__jed_url_checks`
(
	`id`           int unsigned NOT NULL AUTO_INCREMENT,
	`extension_id` int unsigned DEFAULT NULL,
	`field`        varchar(64)  NOT NULL DEFAULT '',
	`validator`    varchar(32)  NOT NULL DEFAULT '',
	`url`          varchar(255) NOT NULL DEFAULT '',
	`url_hash`     char(64)     NOT NULL,
	-- ok | notice | error, per UrlCheckResult. Only `error` ever blocks a save, and only the
	-- format rules produce one - a validator can never write `error` here.
	`state`        varchar(10)  NOT NULL DEFAULT 'notice',
	`http_status`  smallint unsigned NOT NULL DEFAULT '0',
	`message`      varchar(255) NOT NULL DEFAULT '',
	`detail`       varchar(255) DEFAULT NULL,
	`checked_by`   int unsigned NOT NULL DEFAULT '0',
	`checked`      datetime     NOT NULL,
	PRIMARY KEY (`id`),
	KEY `IDX_jed_url_checks_lookup` (`url_hash`, `validator`, `checked`),
	KEY `IDX_jed_url_checks_user` (`checked_by`, `checked`),
	KEY `IDX_jed_url_checks_extension` (`extension_id`, `field`),
	-- SET NULL: this is the moderation record of what was checked and when (P1-08), and it must
	-- outlive the listing it was checked for.
	CONSTRAINT `FK_jed_url_checks_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- One row per listing and URL field, carrying the *current* state of that link (P1-09). Modelled
-- on JED3's `jed_extension_linkcheck_log`, which is why this is parity rather than an idea.
--
-- It is a state table, not a log. A pass over the live stock is roughly 29,000 checks, and
-- writing history for each would produce a table nobody could read and an action log nobody could
-- use (8.15 boundary 2). Only *transitions* - reachable to broken, broken to reachable - reach
-- the action log; the running state and the counter live here.
--
-- fail_count counts *consecutive* failures and resets to 0 on any success. Without that reset an
-- extension accumulates isolated outages over years and eventually alarms for nothing.
CREATE TABLE IF NOT EXISTS `#__jed_extension_linkchecks`
(
	`id`           int unsigned NOT NULL AUTO_INCREMENT,
	`extension_id` int unsigned NOT NULL,
	`link_type`    varchar(32)  NOT NULL,
	`url`          varchar(255) NOT NULL DEFAULT '',
	`last_checked` datetime     DEFAULT NULL,
	-- ok | hard | soft | semantic. The three failure classes are weighted differently on
	-- purpose: a 403 from bot protection is not the same fact as a domain that no longer
	-- resolves, and treating them alike is how a team learns to ignore an alert.
	`status`       varchar(20)  NOT NULL DEFAULT 'ok',
	`http_code`    smallint unsigned DEFAULT NULL,
	`message`      varchar(255) NOT NULL DEFAULT '',
	`fail_count`   int unsigned NOT NULL DEFAULT '0',
	`first_failed` datetime     DEFAULT NULL,
	-- The ticket opened for the *developer* at threshold N. There is no team ticket: at
	-- threshold M this row is flagged instead, and P1-19's abandonware case reads the flag.
	-- Three symptoms of one thing - dead links, a dead update server, long inactivity - must
	-- feed one case, not three ticket streams (4.9, 12.3).
	`ticket_id`    int unsigned DEFAULT NULL,
	`escalated`    tinyint(1)   NOT NULL DEFAULT '0',
	`escalated_time` datetime   DEFAULT NULL,
	PRIMARY KEY (`id`),
	UNIQUE KEY `UQ_jed_linkcheck` (`extension_id`, `link_type`),
	KEY `IDX_jed_linkcheck_due` (`last_checked`),
	KEY `IDX_jed_linkcheck_state` (`status`, `fail_count`),
	KEY `IDX_jed_linkcheck_escalated` (`escalated`),
	-- A state table, not a log (see above) - there is nothing here worth keeping once the
	-- listing it describes is gone.
	CONSTRAINT `FK_jed_extension_linkchecks_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- Raw hits (P1-12). The fastest-growing table on the site by a wide margin: JED3's equivalent
-- holds 2,158,587 rows for a single month, which is where the 30-day retention below comes from -
-- it is not a guess, it is what the legacy system settled on and kept.
--
-- `ip_hash` and not the address. JED3 stores `ip_address char(45)` in clear and there is no reason
-- to repeat that: a salted hash still deduplicates and still supports the abuse work in P1-05,
-- while not being an address. That is also what keeps this table out of P1-18's export and
-- deletion path - with no IP and no user id there is nothing here to hand back or erase.
--
-- No `user_id` column at all, deliberately. 3,905 of JED3's 2.1 million rows were from a
-- logged-in visitor, so it would identify almost nobody while making the table personal data for
-- everybody.
CREATE TABLE IF NOT EXISTS `#__jed_hit_log`
(
	`id`           bigint unsigned NOT NULL AUTO_INCREMENT,
	`extension_id` int unsigned    NOT NULL,
	`hit_type`     enum('view', 'download_click') NOT NULL DEFAULT 'view',
	`hit_time`     datetime        NOT NULL,
	`ip_hash`      varbinary(32)   DEFAULT NULL,
	`user_agent`   varchar(255)    DEFAULT NULL,
	-- Marked, never blocked. A false positive that blocks costs a real visitor their download;
	-- one that mislabels costs a row in an aggregate nobody would have noticed.
	`is_robot`     tinyint(1)      NOT NULL DEFAULT '0',
	`suspicious`   tinyint(1)      NOT NULL DEFAULT '0',
	PRIMARY KEY (`id`),
	KEY `IDX_jed_hitlog_ext_time` (`extension_id`, `hit_time`),
	KEY `IDX_jed_hitlog_time` (`hit_time`),
	KEY `IDX_jed_hitlog_rate` (`ip_hash`, `hit_time`),
	CONSTRAINT `FK_jed_hit_log_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- The daily aggregate. Separate from the log because the two answer different questions and have
-- opposite lifetimes: the log is evidence for a few weeks, this is the record that stays.
--
-- Robots and suspicious hits are counted *out* of views and download_clicks and kept in their own
-- columns rather than discarded, so "12% of our traffic is bots" stays answerable after the raw
-- rows are gone.
CREATE TABLE IF NOT EXISTS `#__jed_hit_stats`
(
	`extension_id`    int unsigned NOT NULL,
	`period`          date         NOT NULL,
	`views`           int unsigned NOT NULL DEFAULT '0',
	`download_clicks` int unsigned NOT NULL DEFAULT '0',
	`robot_hits`      int unsigned NOT NULL DEFAULT '0',
	PRIMARY KEY (`extension_id`, `period`),
	KEY `IDX_jed_hitstats_period` (`period`),
	CONSTRAINT `FK_jed_hit_stats_extension_id` FOREIGN KEY (`extension_id`) REFERENCES `#__jed_extensions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------------------------
-- The ticket system: the moderation correspondence with developers and reporters.
--
-- Every ticket about a listing, a review or a developer response lands here, whether a person
-- opened it from the site form or the machinery did (a submission, a flagged review, the link
-- checker, an abandonware case). The three small tables in front of it are the vocabularies the
-- ticket form offers - category, allocation group, linked-item type - seeded below so a fresh
-- install has something to pick from; the JED team maintains them as data from then on.
--
-- No foreign keys out of `#__jed_tickets`: `linked_item_id` points at a different table per
-- `linked_item_type` (an extension, a review, an abandonware case), which is not something a
-- constraint can express, and a ticket must in any case outlive the thing it was about - "why was
-- this listing removed" is a question asked after the listing is gone.
-- ---------------------------------------------------------------------------------------------

/* Ticket Category Types */
CREATE TABLE IF NOT EXISTS `#__jed_ticket_categories`
(
	`id`               int unsigned NOT NULL AUTO_INCREMENT,
	`categorytype`     varchar(255) DEFAULT '',
	`ordering`         int          DEFAULT '0',
	`state`            tinyint(1)   DEFAULT '1',
	`checked_out`      int unsigned,
	`checked_out_time` datetime,
	`created_by`       int unsigned NOT NULL,
	`modified_by`      int unsigned NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `#__jed_ticket_categories`(`id`, `categorytype`, `ordering`, `state`, `checked_out`, `checked_out_time`, `created_by`, `modified_by`) VALUES
(1, 'Unknown', 0, 1, NULL, NULL, 652, 652),
(2, 'Extension', 0, 1, NULL, NULL, 652, 652),
(3, 'Review', 0, 1, NULL, NULL, 652, 652),
(4, 'Joomla Site Issue', 0, 1, NULL, NULL, 652, 652),
(5, 'New Listing Support', 0, 1, NULL, NULL, 652, 652),
(6, 'Current Listing Support', 0, 1, NULL, NULL, 652, 652),
(7, 'Site Technical Issues', 0, 1, NULL, NULL, 652, 652),
(8, 'Unpublished Support', 0, 1, NULL, NULL, 652, 652),
(9, 'Reported Review', 0, 1, NULL, NULL, 652, 652),
(10, 'Reported Extension', 0, 1, NULL, NULL, 652, 652);


/* Ticket Allocation Groups */
CREATE TABLE IF NOT EXISTS `#__jed_ticket_groups`
(
	`id`               int unsigned NOT NULL AUTO_INCREMENT,
	`name`             varchar(255) DEFAULT '',
	`ordering`         int          DEFAULT '0',
	`state`            tinyint(1)   DEFAULT '1',
	`checked_out`      int unsigned,
	`checked_out_time` datetime,
	`created_by`       int unsigned NOT NULL,
	`modified_by`      int unsigned NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `#__jed_ticket_groups`(`id`, `name`, `ordering`, `state`, `checked_out`, `checked_out_time`, `created_by`, `modified_by`) VALUES
(1, 'Any', 0, 1, NULL, NULL, 652, 652),
(2, 'Team Leadership', 0, 1, NULL, NULL, 652, 652),
(3, 'Listing Specialist', 0, 1, NULL, NULL, 652, 652),
(4, 'Review Specialist', 0, 1, NULL, NULL, 652, 652),
(5, 'Support Specialist', 0, 1, NULL, NULL, 652, 652);


/* Ticket Linked Items */
CREATE TABLE IF NOT EXISTS `#__jed_ticket_linked_item_types`
(
	`id`               int unsigned NOT NULL AUTO_INCREMENT,
	`title`            varchar(255) DEFAULT '',
	`model`            varchar(255) DEFAULT '',
	`ordering`         int          DEFAULT '0',
	`state`            tinyint(1)   DEFAULT '1',
	`checked_out`      int unsigned,
	`checked_out_time` datetime,
	`created_by`       int unsigned NOT NULL,
	`modified_by`      int unsigned NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `#__jed_ticket_linked_item_types`(`id`, `title`, `model`, `ordering`, `state`, `checked_out`, `checked_out_time`, `created_by`, `modified_by`) VALUES
(1, 'Unknown', 'unknown', 0, 1, NULL, NULL, 652, 652),
(2, 'Extension', 'Extension', 1, 1, NULL, NULL, 652, 652),
(3, 'Review', 'Review', 0, 1, NULL, NULL, 652, 652),
(4, 'Vulnerable Item Initial Report', 'Velreport', 0, 1, NULL, NULL, 652, 652),
(5, 'Vulnerable Item Developer Update', 'Veldeveloperupdate', 0, 1, NULL, NULL, 652, 652),
(6, 'VEL Abandonware Report', 'Velabandonedreport', 0, 1, NULL, NULL, 652, 652);


/* Vulnerable Extension Lists (VEL) */

CREATE TABLE IF NOT EXISTS `#__jed_vel_report`
(
	`id`                               int unsigned NOT NULL AUTO_INCREMENT,
	`reporter_fullname`                varchar(255) NOT NULL DEFAULT '',
	`reporter_email`                   varchar(255) NOT NULL DEFAULT '',
	`reporter_organisation`            varchar(255) NOT NULL DEFAULT '',
	`pass_details_ok`                  int          NOT NULL DEFAULT '0',
	`vulnerability_type`               int          NOT NULL DEFAULT '0',
	`vulnerable_item_name`             varchar(255) NOT NULL DEFAULT '',
	`vulnerable_item_version`          varchar(255) NOT NULL DEFAULT '',
	`exploit_type`                     int          NOT NULL DEFAULT '0',
	`exploit_other_description`        text         NOT NULL,
	`vulnerability_description`        text         NOT NULL,
	`vulnerability_how_found`          text         NOT NULL,
	`vulnerability_actively_exploited` int          NOT NULL DEFAULT '0',
	`vulnerability_publicly_available` int          NOT NULL DEFAULT '0',
	`vulnerability_publicly_url`       varchar(255) NOT NULL DEFAULT '',
	`vulnerability_specific_impact`    text         NOT NULL,
	`developer_communication_type`     int          NOT NULL DEFAULT '0',
	`developer_patch_download_url`     varchar(255) NOT NULL DEFAULT '',
	`developer_name`                   varchar(255) NOT NULL DEFAULT '',
	`developer_contact_email`          varchar(255) NOT NULL DEFAULT '',
	`tracking_db_name`                 varchar(255) NOT NULL DEFAULT '',
	`tracking_db_id`                   varchar(255) NOT NULL DEFAULT '',
	`jed_url`                          varchar(255) NOT NULL DEFAULT '',
	`developer_additional_info`        text         NOT NULL,
	`download_url`                     varchar(255) NOT NULL DEFAULT '',
	`consent_to_process`               int          NOT NULL DEFAULT '0',
	`passed_to_vel`                    int          NOT NULL DEFAULT '0',
	`vel_item_id`                      int          NOT NULL DEFAULT '0',
	`data_source`                      int          NOT NULL DEFAULT '0',
	`date_submitted`                   datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`user_ip`                          varchar(20)  NOT NULL DEFAULT '',
	`created_by`                       int          NOT NULL DEFAULT '0',
	`modified_by`                      int          NOT NULL DEFAULT '0',
	`created`                          datetime,
	`modified`                         datetime,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__jed_vel_developer_update`
(
	`id`                      int unsigned NOT NULL AUTO_INCREMENT,
	`contact_fullname`        varchar(255) NOT NULL DEFAULT '',
	`contact_organisation`    varchar(255) NOT NULL DEFAULT '',
	`contact_email`           varchar(255) NOT NULL DEFAULT '',
	`vulnerable_item_name`    varchar(255) NOT NULL DEFAULT '',
	`vulnerable_item_version` varchar(255) NOT NULL DEFAULT '',
	`extension_update`        text         NOT NULL,
	`new_version_number`      varchar(255) NOT NULL DEFAULT '',
	`update_notice_url`       varchar(255) NOT NULL DEFAULT '',
	`changelog_url`           varchar(255) NOT NULL DEFAULT '',
	`download_url`            varchar(255) NOT NULL DEFAULT '',
	`consent_to_process`      int                   DEFAULT '0',
	`vel_item_id`             int          NOT NULL DEFAULT '0',
	`update_data_source`      int          NOT NULL DEFAULT '0',
	`update_date_submitted`   datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`update_user_ip`          varchar(20)  NOT NULL DEFAULT '',
	`created_by`              int          NOT NULL DEFAULT '0',
	`modified_by`             int          NOT NULL DEFAULT '0',
	`created`                 datetime,
	`modified`                datetime,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__jed_vel_abandoned_report`
(
	`id`                    int unsigned NOT NULL AUTO_INCREMENT,
	`reporter_fullname`     varchar(255) NOT NULL,
	`reporter_email`        varchar(255) NOT NULL,
	`reporter_organisation` varchar(255) NULL     DEFAULT '',
	`extension_name`        varchar(255) NOT NULL,
	`developer_name`        varchar(255) NULL     DEFAULT '',
	`extension_version`     varchar(255) NULL     DEFAULT '',
	`extension_url`         varchar(255) NULL     DEFAULT '',
	`abandoned_reason`      text         NULL,
	`consent_to_process`    varchar(255) NOT NULL DEFAULT '0',
	`passed_to_vel`         varchar(255) NULL     DEFAULT '0',
	`vel_item_id`           int          NULL     DEFAULT 0,
	`data_source`           varchar(255) NULL     DEFAULT '0',
	`date_submitted`        datetime     NULL     DEFAULT CURRENT_TIMESTAMP,
	`user_ip`               varchar(20)  NULL     DEFAULT '',
	`created_by`            int          NULL     DEFAULT 0,
	`modified_by`           int          NULL     DEFAULT 0,
	`created`               datetime,
	`modified`              datetime,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__jed_vel_vulnerable_item`
(
	`id`                        int unsigned  NOT NULL AUTO_INCREMENT,
	`vulnerable_item_name`      varchar(255)  NOT NULL DEFAULT '',
	`vulnerable_item_version`   varchar(255)  NOT NULL DEFAULT '',
	`title`                     varchar(255)  NOT NULL DEFAULT '',
	`internal_description`      text          NOT NULL,
	`status`                    int           NOT NULL DEFAULT '0',
	`report_id`                 int           NOT NULL DEFAULT '-1',
	`jed`                       varchar(255)  NOT NULL DEFAULT '',
	`risk_level`                varchar(255)  NOT NULL DEFAULT '',
	`start_version`             varchar(255)  NOT NULL DEFAULT '',
	`vulnerable_version`        varchar(255)  NOT NULL DEFAULT '',
	`patch_version`             varchar(255)  NOT NULL DEFAULT '',
	`recommendation`            varchar(255)  NOT NULL DEFAULT '',
	`update_notice`             varchar(255)  NOT NULL DEFAULT '',
	`exploit_type`              int           NOT NULL DEFAULT '0',
	`exploit_other_description` text          NOT NULL,
	`xml_manifest`              text          NOT NULL,
	`manifest_location`         varchar(255)  NOT NULL DEFAULT '',
	`install_data`              varchar(255)  NOT NULL DEFAULT '',
	`discovered_by`             varchar(255)  NOT NULL DEFAULT '',
	`discoverer_public`         varchar(255)  NOT NULL DEFAULT '',
	`fixed_by`                  varchar(255)  NOT NULL DEFAULT '',
	`coordinated_by`            varchar(255)  NOT NULL DEFAULT '',
	`jira`                      varchar(255)  NOT NULL DEFAULT '',
	`cve_id`                    varchar(255)  NOT NULL DEFAULT '',
	`cwe_id`                    varchar(255)  NOT NULL DEFAULT '',
	`cvssthirty_base`           varchar(255)  NOT NULL DEFAULT '',
	`cvssthirty_base_score`     decimal(5, 2) NOT NULL DEFAULT '0.00',
	`cvssthirty_temp`           varchar(255)  NOT NULL DEFAULT '',
	`cvssthirty_temp_score`     decimal(5, 2) NOT NULL DEFAULT '0.00',
	`cvssthirty_env`            varchar(255)  NOT NULL DEFAULT '',
	`cvssthirty_env_score`      decimal(5, 2) NOT NULL DEFAULT '0.00',
	`public_description`        text          NOT NULL,
	`alias`                     varchar(255)  NOT NULL DEFAULT '',
	`created_by`                int           NOT NULL DEFAULT '0',
	`modified_by`               int           NOT NULL DEFAULT '0',
	`created`                   datetime,
	`modified`                  datetime,
	`checked_out`               int unsigned,
	`checked_out_time`          datetime,
	`state`                     tinyint       NOT NULL DEFAULT '0',
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


/* JED Ticket Messages */
CREATE TABLE IF NOT EXISTS `#__jed_ticket_messages`
(
	`id`                int unsigned NOT NULL AUTO_INCREMENT,
	`ticket_id`         int          DEFAULT '0',
	`subject`           varchar(255) NOT NULL,
	`message`           text,
	`message_direction` int          DEFAULT '0',
	`internal`          tinyint(1)   DEFAULT '0',
	`created_by`        int unsigned NOT NULL,
	`created_on`        datetime     DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


/* JED Ticket Internal Notes */
-- The JED team's own notes on a ticket: for the team only, never shown to the ticket's creator and
-- never mailed. Separate from a message flagged `internal` in #__jed_ticket_messages - that is a
-- reply in the thread hidden from the requester, this is not part of the conversation at all.
-- `#__jed_tickets`.`internal_notes` next to it is the single legacy block the JED3 migration
-- carries across per ticket; notes written in JED4 land here, one row each, attributed and dated.
CREATE TABLE IF NOT EXISTS `#__jed_ticket_internal_notes`
(
	`id`               int unsigned NOT NULL AUTO_INCREMENT,
	`ticket_id`        int          NULL DEFAULT 0,
	`summary`          varchar(255) NULL DEFAULT '',
	`note`             text         NULL,
	`ordering`         int          NULL DEFAULT 0,
	`state`            tinyint(1)   NULL DEFAULT 1,
	`checked_out`      int unsigned,
	`checked_out_time` datetime,
	`created_by`       int unsigned NOT NULL DEFAULT 0,
	`modified_by`      int unsigned NULL DEFAULT 0,
	`created_on`       datetime     DEFAULT NULL,
	PRIMARY KEY (`id`),
	KEY `IDX_jed_ticket_internal_notes_ticket` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


/* JED Tickets */
CREATE TABLE IF NOT EXISTS `#__jed_tickets`
(
	`id`                      int unsigned NOT NULL AUTO_INCREMENT,
	`ticket_origin`           int          NULL DEFAULT 0,
	`ticket_category_type`    int          NULL DEFAULT 0,
	`ticket_subject`          varchar(255) NULL DEFAULT '',
	`ticket_text`             text         NULL,
	`internal_notes`          text         NULL,
	`uploaded_files_preview`  blob         NULL,
	`uploaded_files_location` varchar(255) NULL DEFAULT '',
	`allocated_group`         int          NULL DEFAULT 0,
	`allocated_to`            int          NULL DEFAULT 0,
	`linked_item_type`        int          NULL DEFAULT 0,
	`linked_item_id`          int          NULL DEFAULT 0,
	`ticket_status`           INT          NULL DEFAULT 0,
	`parent_id`               int          NULL DEFAULT -1,
	`state`                   tinyint(1)   NOT NULL DEFAULT 0,
	`ordering`                int          NULL DEFAULT 0,
	`created_by`              int unsigned NOT NULL,
	`created_on`              datetime,
	`modified_by`             int unsigned NULL,
	`modified_on`             datetime,
	`checked_out`             int unsigned,
	`checked_out_time`        datetime,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


INSERT IGNORE INTO `#__mail_templates` (`template_id`, `extension`, `language`, `subject`, `body`, `htmlbody`, `attachments`, `params`) VALUES
('com_jed.audit_report', 'com_jed', '', 'COM_JED_AUDIT_REPORT_EMAIL_SUBJECT', 'COM_JED_AUDIT_REPORT_EMAIL_BODY', '', '', '{"tags":["sitename","extensionname","extensionversion","phpstanreport","claudereport"]}'),
('com_jed.link_broken', 'com_jed', '', 'COM_JED_LINKCHECK_EMAIL_SUBJECT', 'COM_JED_LINKCHECK_EMAIL_BODY', '', '', '{"tags":["sitename","extensionname","linktype","url","reason","since","ticketlink"]}');


SET FOREIGN_KEY_CHECKS = 1;
