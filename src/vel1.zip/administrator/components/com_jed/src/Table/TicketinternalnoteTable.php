<?php

/**
 * @package JED
 *
 * @subpackage Tickets
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jed\Component\Jed\Administrator\Table;

// No direct access
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Exception;
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

/**
 * Ticket internal note table.
 *
 * A note the JED team writes *about* a ticket, for the team only - it is never shown to the
 * ticket's creator and never mailed. Distinct from a ticket message flagged `internal`, which is a
 * reply in the thread that happens to be hidden from the requester: a note is not part of the
 * conversation at all, which is why it has its own table rather than a flag on
 * `#__jed_ticket_messages`.
 *
 * @since 4.0.0
 */
class TicketinternalnoteTable extends Table
{
    /**
     * Constructor
     *
     * @param DatabaseDriver $db A database connector object
     *
     * @since 4.0.0
     */
    public function __construct(DatabaseDriver $db)
    {
        $this->typeAlias = 'com_jed.ticketinternalnote';
        parent::__construct('#__jed_ticket_internal_notes', 'id', $db);
        $this->setColumnAlias('published', 'state');
    }

    /**
     * Define a namespaced asset name for inclusion in the #__assets table
     *
     * @return string The asset name
     *
     * @see   Table::_getAssetName
     * @since 4.0.0
     */
    protected function _getAssetName(): string
    {
        $k = $this->_tbl_key;

        return $this->typeAlias . '.' . (int) $this->$k;
    }

    /**
     * Overloaded bind function to pre-process the params.
     *
     * @param array|object $src    An associative array or object to bind to the Table instance.
     * @param array|string $ignore An optional array or space separated list of properties to ignore while binding.
     *
     * @return bool  True on success.
     *
     * @see    Table:bind
     * @since  4.0.0
     * @throws Exception
     */
    public function bind($src, $ignore = '')
    {
        $date = Factory::getDate();
        $user = Factory::getApplication()->getIdentity();

        if ($src['id'] == 0 && empty($src['created_by'])) {
            $src['created_by'] = $user->id;
        }

        if (empty($src['modified_by'])) {
            $src['modified_by'] = $user->id;
        }

        // Support for multiple or not foreign key field: ticket_id
        if (!empty($src['ticket_id'])) {
            if (is_array($src['ticket_id'])) {
                $src['ticket_id'] = implode(',', $src['ticket_id']);
            }
        } else {
            $src['ticket_id'] = 0;
        }

        if ($src['id'] == 0) {
            $src['created_on'] = $date->toSql();
        }

        return parent::bind($src, $ignore);
    }

    /**
     * Delete a record by id
     *
     * @param mixed $pk Primary key value to delete. Optional
     *
     * @return bool
     *
     * @since 4.0.0
     */
    public function delete($pk = null): bool
    {
        $this->load($pk);

        return parent::delete($pk);
    }

    /**
     * Get the type alias for the history table
     *
     * @return string  The alias as described above
     *
     * @since 4.0.0
     */
    public function getTypeAlias(): string
    {
        return $this->typeAlias;
    }
}
