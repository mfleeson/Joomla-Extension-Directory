<?php

/**
 * @package JED
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jed\Component\Jed\Administrator\View\Extensions;

// No direct access
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Jed\Component\Jed\Administrator\Helper\JedHelper;
use Jed\Component\Jed\Administrator\Model\ExtensionsModel;
use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\HTML\Helpers\Sidebar;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarFactoryInterface;
use Joomla\Registry\Registry;
use Joomla\CMS\Pagination\Pagination;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\Component\Content\Administrator\Extension\ContentComponent;

/**
 * View class for a list of Extensions.
 *
 * @since 4.0.0
 */
class HtmlView extends BaseHtmlView
{
    public ?Form $filterForm    = null;
    public array $activeFilters = [];
    public string $sidebar;
    protected array $items = [];
    protected Pagination $pagination;
    /**
     * The model state
     *
     * @var Registry
     *
     * @since 4.0.0
     */
    protected Registry $state;

    /**
     * Display the view
     *
     * @param string $tpl Template name
     *
     * @return void
     *
     * @since  4.0.0
     * @throws Exception
     */
    public function display($tpl = null): void
    {
        /**
 * @var ExtensionsModel $model
*/
        $model               = $this->getModel();
        $model->setUseExceptions(true);

        $this->state         = $model->getState();
        $this->items         = $model->getItems();
        $this->pagination    = $model->getPagination();
        $this->filterForm    = $model->getFilterForm();
        $this->activeFilters = $model->getActiveFilters();


        $this->addToolbar();

        $this->sidebar = Sidebar::render();
        parent::display($tpl);
    }

    /**
     * Add the page title and toolbar.
     *
     * @return void
     *
     * @since  4.0.0
     * @throws Exception
     */
    protected function addToolbar(): void
    {
        /* @var HtmlDocument $doc */
        $doc   = $this->getDocument();
        $canDo = JedHelper::getActions('com_jed', 'extension');

        ToolbarHelper::title(Text::_('COM_JED_EXTENSIONS'), "generic");

        $toolbar = $doc->getToolbar();

        if ($canDo->get('core.create')) {
            $toolbar->addNew('extension.add');
        }

        if ($canDo->get('core.edit.state')) {
            $dropdown = $toolbar->dropdownButton('status-group')
                ->text('JTOOLBAR_CHANGE_STATUS')
                ->toggleSplit(false)
                ->icon('fas fa-ellipsis-h')
                ->buttonClass('btn btn-action')
                ->listCheck(true);

            $childBar = $dropdown->getChildToolbar();

            if (isset($this->items[0]->state)) {
                $childBar->publish('extensions.publish')->listCheck(true);
                $childBar->unpublish('extensions.unpublish')->listCheck(true);
                $childBar->archive('extensions.archive')->listCheck(true);
            } elseif (isset($this->items[0])) {
                // If this component does not use state then show a direct delete button as we can not trash
                $toolbar->delete('extensions.delete')
                    ->text('JTOOLBAR_EMPTY_TRASH')
                    ->message('JGLOBAL_CONFIRM_DELETE')
                    ->listCheck(true);
            }

            $childBar->standardButton('duplicate')
                ->text('JTOOLBAR_DUPLICATE')
                ->icon('fas fa-copy')
                ->task('extensions.duplicate')
                ->listCheck(true);

            if (isset($this->items[0]->checked_out)) {
                $childBar->checkin('extensions.checkin')->listCheck(true);
            }

            if (isset($this->items[0]->state)) {
                $childBar->trash('extensions.trash')->listCheck(true);
            }
        }


        // Show trash and delete for components that uses the state field
        if (isset($this->items[0]->state)) {
            if ($this->state->get('filter.state') == ContentComponent::CONDITION_TRASHED && $canDo->get('core.delete')) {
                $toolbar->delete('extensions.delete')
                    ->text('JTOOLBAR_EMPTY_TRASH')
                    ->message('JGLOBAL_CONFIRM_DELETE')
                    ->listCheck(true);
            }
        }
        JedHelper::addConfigToolbar($toolbar);
        if ($canDo->get('core.admin')) {
            $toolbar->preferences('com_jed');
        }
        // Set sidebar action
        Sidebar::setAction('index.php?option=com_jed&view=extensions');
    }

    /**
     * Method to order fields
     *
     * @return array
     *
     * @since 4.0.0
     */
    protected function getSortFields(): array
    {
        return [
            'a.`id`'                    => Text::_('JGRID_HEADING_ID'),
            'a.`name`'                  => Text::_('COM_JED_GENERAL_TITLE_LABEL'),
            'a.`alias`'                 => Text::_('COM_JED_GENERAL_ALIAS_LABEL'),
            'a.`joomla_versions`'       => Text::_('COM_JED_EXTENSION_JOOMLA_VERSIONS_LABEL'),
            'a.`popular`'               => Text::_('COM_JED_EXTENSION_POPULAR_LABEL'),
            'a.`requires_registration`' => Text::_('COM_JED_EXTENSION_REQUIRES_REGISTRATION_LABEL'),
            'a.`type`'                  => Text::_('COM_JED_GENERAL_TYPE_LABEL'),
            'a.`extension_types`'       => Text::_('COM_JED_GENERAL_INCLUDES_LABEL'),
            'a.`approved_time`'         => Text::_('COM_JED_EXTENSION_APPROVED_TIME_LABEL'),
            'a.`catid`'                 => Text::_('COM_JED_GENERAL_CATEGORY_ID_LABEL_LABEL'),
            'a.`state`'                 => Text::_('COM_JED_EXTENSION_STATE_LABEL'),
        ];
    }
}
