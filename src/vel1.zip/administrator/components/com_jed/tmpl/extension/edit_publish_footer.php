<?php

/**
 * @package JED
 *
 * @copyright (C) 2006-2026 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Joomla\CMS\Language\Text;

/** @var \Jed\Component\Jed\Administrator\View\Extension\HtmlView $this */

?>
<button type="button" class="btn" data-bs-dismiss="modal">
    <?php echo Text::_('JCANCEL'); ?>
</button>
<button type="button" class="btn btn-success" onclick="jed.submitPublishedState(<?php echo $this->item->id; ?>);">
    <?php echo Text::_('JAPPLY'); ?>
</button>
